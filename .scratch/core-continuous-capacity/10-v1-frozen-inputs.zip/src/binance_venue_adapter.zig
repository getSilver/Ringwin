//! Binance execution implementation of the shared VenueAdapter seam.
//!
//! Venue request fields, credentials, signatures, limits, and response JSON
//! remain here. Callers supply only canonical OrderCommand values.

const std = @import("std");
const canonical = @import("canonical_event.zig");
const venue = @import("venue_adapter.zig");
const contract = @import("venue_adapter_contract.zig");
const raw = @import("binance_order_raw.zig");
const private = @import("binance_private_reconciliation.zig");

pub const btc_usdt_spot: canonical.InstrumentIdentity = 0x424e_00000001;
pub const btc_usdt_linear: canonical.InstrumentIdentity = 0x424e_00000002;

pub const InstrumentRules = struct { identity: canonical.InstrumentIdentity, tick_size: canonical.Decimal, lot_size: canonical.Decimal };
/// Execution authority for this fixed Binance Testnet session.  It is private
/// to the Venue implementation: the generic Gateway only sees canonical facts.
pub const TestnetAdmission = struct {
    explicit_enable: bool = false,
    endpoint_is_testnet: bool = false,
    credential_can_read: bool = false,
    credential_can_trade: bool = false,
    credential_can_withdraw: bool = true,
    max_order_notional_usdt_micros: u64 = 25_000_000,

    pub fn permitsPlace(self: TestnetAdmission) bool {
        return self.explicit_enable and self.endpoint_is_testnet and self.credential_can_read and self.credential_can_trade and !self.credential_can_withdraw and self.max_order_notional_usdt_micros > 0;
    }
};
pub const CapabilityProfile = struct {
    version: u64,
    rules_version: u64,
    config_version: u64,
    session: u64,
    spot: InstrumentRules,
    linear: InstrumentRules,
    batch_max: u8 = canonical.max_order_commands_per_batch,
    /// Required/target encoding capability. Not live Testnet evidence.
    native_amend: bool = true,
    native_post_only: bool = true,
    venue_reduce_only_linear: bool = true,
    verified_native_amend: bool = false,
    verified_native_post_only: bool = false,
    verified_bounded_batch: bool = false,
    verified_venue_reduce_only_linear: bool = false,
    requests_per_window: u8 = 4,
    window_ns: u64 = std.time.ns_per_s,
    testnet_admission: TestnetAdmission = .{},
    qualification: @import("production_contract.zig").Qualification = .not_run,
};

pub const Authenticator = struct {
    ptr: *anyopaque,
    sign_fn: *const fn (*anyopaque, u64, []const u8) anyerror![32]u8,
    pub fn sign(self: Authenticator, timestamp: u64, body: []const u8) ![32]u8 {
        return self.sign_fn(self.ptr, timestamp, body);
    }
};
pub const TransportOutcome = enum { proven_before_send, response, write_or_response_uncertain };
pub const HttpMethod = enum { post, delete, put };
pub const SignedRequest = struct { method: HttpMethod, path: []const u8, body: []const u8, timestamp_ns: u64, signature: [32]u8 };
pub const TransportResult = struct { outcome: TransportOutcome, response: ?[]const u8 = null, source_session: u64, times: raw.Times };
pub const Transport = struct {
    ptr: *anyopaque,
    submit_fn: *const fn (*anyopaque, SignedRequest) TransportResult,
    pub fn submit(self: Transport, request: SignedRequest) TransportResult {
        return self.submit_fn(self.ptr, request);
    }
};

const State = enum { idle, running, stopped };
const Binding = struct { venue: canonical.VenueIdentity, account: canonical.ExchangeAccountIdentity, session: canonical.AdapterSessionIdentity };
const Rate = struct { window_start: u64 = 0, count: u8 = 0 };
const max_unknown_orders = 32;
const Encoded = struct {
    method: HttpMethod,
    path: []const u8,
    timestamp_ns: u64,
    bytes: [512]u8 = undefined,
    len: usize,
    fn body(self: *const Encoded) []const u8 {
        return self.bytes[0..self.len];
    }
};

pub const BinanceVenueAdapter = struct {
    asset_definitions: @import("asset_registry.zig").Registry = .{},
    native_settlement_atoms: bool = false,
    instrument_definitions: @import("instrument_registry.zig").Registry = .{},
    clock: Clock,
    profile: CapabilityProfile,
    auth: Authenticator,
    raw_sink: raw.RawSink,
    transport: Transport,
    state: State = .idle,
    binding: ?Binding = null,
    pending: ?canonical.AdapterOutputBatch = null,
    next_event_sequence: u64 = 1,
    rate: Rate = .{},
    unknown_orders: [max_unknown_orders]canonical.OrderIdentity = undefined,
    unknown_count: u8 = 0,
    unknown_overflow: bool = false,
    private_reconciler: ?*private.Reconciler = null,
    private_failed: bool = false,
    pending_account_reconciliation: ?u128 = null,

    pub const Clock = struct {
        ptr: *anyopaque,
        now_fn: *const fn (*anyopaque) u64,
        pub fn now(self: Clock) u64 {
            return self.now_fn(self.ptr);
        }
    };
    pub fn init(clock: Clock, capability_profile: CapabilityProfile, auth: Authenticator, raw_sink: raw.RawSink, transport: Transport) BinanceVenueAdapter {
        return .{ .clock = clock, .profile = capability_profile, .auth = auth, .raw_sink = raw_sink, .transport = transport };
    }
    pub fn adapter(self: *BinanceVenueAdapter) venue.VenueAdapter {
        return .{ .ptr = self, .vtable = &.{ .start = start, .try_send = send, .try_drain = drain, .stop = stop } };
    }
    /// The transport remains private; callers can only retrieve the resulting
    /// CanonicalEvent records through the shared adapter drain seam.
    pub fn attachPrivateReconciler(self: *BinanceVenueAdapter, reconciler: *private.Reconciler) void {
        self.private_reconciler = reconciler;
        reconciler.asset_definitions = self.asset_definitions;
    }
    pub fn beginPrivateReconciliation(self: *BinanceVenueAdapter) !void {
        if (self.state != .running) return error.NotStarted;
        const reconciler = self.private_reconciler orelse return error.PrivateReconcilerMissing;
        try reconciler.beginReconciliation(reconciler.readiness().raw_watermark);
    }
    pub fn beginPrivateSession(self: *BinanceVenueAdapter) !void {
        const binding = self.binding orelse return error.NotStarted;
        const reconciler = self.private_reconciler orelse return error.PrivateReconcilerMissing;
        reconciler.beginSession(.{ .venue = binding.venue, .account = binding.account, .session = binding.session });
    }
    pub fn ingestPrivate(self: *BinanceVenueAdapter, allocator: std.mem.Allocator, source: private.Source, page: ?private.Page, times: raw.Times, bytes: []const u8) !raw.RawEvidenceRef {
        if (self.state != .running) return error.NotStarted;
        return (self.private_reconciler orelse return error.PrivateReconcilerMissing).ingest(allocator, source, page, times, bytes) catch |err| {
            self.private_failed = true;
            return err;
        };
    }

    pub fn replayPrivate(self: *BinanceVenueAdapter, allocator: std.mem.Allocator, source: private.Source, page: ?private.Page, times: raw.Times, evidence: raw.RawEvidenceRef, bytes: []const u8) !void {
        if (self.state != .running) return error.NotStarted;
        return (self.private_reconciler orelse return error.PrivateReconcilerMissing).replay(allocator, source, page, times, evidence, bytes) catch |err| {
            self.private_failed = true;
            return err;
        };
    }

    pub fn replayEconomicRequest(self: *BinanceVenueAdapter, bytes: []const u8) !void {
        if (self.state != .running) return error.NotStarted;
        try (self.private_reconciler orelse return error.PrivateReconcilerMissing).replayEconomicRequest(bytes);
    }
    pub fn privateSourceGap(self: *BinanceVenueAdapter) void {
        if (self.private_reconciler) |reconciler| reconciler.sourceGap();
    }

    fn start(ptr: *anyopaque, config: venue.VenueConfig) venue.StartError!void {
        const self: *BinanceVenueAdapter = @ptrCast(@alignCast(ptr));
        if (self.state == .running) return error.AlreadyStarted;
        if (self.state == .stopped) return error.Stopped;
        if (config.environment != .demo or config.venue == 0 or config.exchange_account == 0 or config.adapter_session == 0 or config.adapter_session > std.math.maxInt(u64) or config.request_capacity == 0 or config.output_capacity < canonical.max_order_commands_per_batch or self.profile.session != @as(u64, @intCast(config.adapter_session))) return error.InvalidConfig;
        self.asset_definitions = config.asset_definitions orelse .{};
        self.native_settlement_atoms = config.native_settlement_atoms;
        self.asset_definitions.validate() catch return error.InvalidConfig;
        self.instrument_definitions = config.instrument_definitions orelse .{};
        self.instrument_definitions.validate() catch return error.InvalidConfig;
        if (self.native_settlement_atoms and self.instrument_definitions.count == 0) return error.InvalidConfig;
        for ([_]InstrumentRules{ self.profile.spot, self.profile.linear }) |configured| {
            if (self.instrument_definitions.get(configured.identity) != null)
                self.instrument_definitions.validateVenueUnits(&self.asset_definitions, configured.identity, self.profile.rules_version, configured.lot_size, configured.tick_size) catch return error.InvalidConfig;
        }
        if (self.private_reconciler) |reconciler| {
            for ([_]private.InstrumentRules{ reconciler.rules.spot, reconciler.rules.linear }) |configured| {
                if (self.instrument_definitions.get(configured.identity) != null)
                    self.instrument_definitions.validateVenueUnits(&self.asset_definitions, configured.identity, configured.rules_version, configured.lot_size, configured.tick_size) catch return error.InvalidConfig;
            }
        }
        self.binding = .{ .venue = config.venue, .account = config.exchange_account, .session = config.adapter_session };
        if (self.private_reconciler) |reconciler|
            reconciler.beginSession(.{ .venue = config.venue, .account = config.exchange_account, .session = config.adapter_session });
        if (self.private_reconciler) |reconciler| reconciler.asset_definitions = self.asset_definitions;
        self.state = .running;
    }
    fn send(ptr: *anyopaque, request: canonical.AdapterRequest) venue.SendError!venue.SendResult {
        const self: *BinanceVenueAdapter = @ptrCast(@alignCast(ptr));
        if (self.state == .idle) return error.NotStarted;
        if (self.state == .stopped) return .stopped;
        if (self.pending != null) return .backpressure;
        switch (request) {
            .order_reconciliation => |reconciliation| return self.reconcileOrder(reconciliation),
            .account_reconciliation => |reconciliation| return self.reconcileAccount(reconciliation),
            else => {},
        }
        var commands: [canonical.max_order_commands_per_batch]canonical.OrderCommand = undefined;
        const count: usize = switch (request) {
            .order_command => |value| blk: {
                commands[0] = value;
                break :blk 1;
            },
            .order_batch => |batch| blk: {
                if (batch.len == 0) return error.InvalidRequest;
                @memcpy(commands[0..batch.len], batch.slice());
                break :blk batch.len;
            },
            else => return error.InvalidRequest,
        };
        var output: canonical.AdapterOutputBatch = .{};
        for (commands[0..count]) |command| {
            if (command.operation != .cancel and (self.private_failed or !self.instrument_definitions.permitsEconomicUnits(&self.asset_definitions, command.instrument))) return .backpressure;
        }
        if (count > self.profile.batch_max or count > canonical.max_order_commands_per_batch) {
            for (commands[0..count]) |command| self.append(&output, command, .not_sent, .adapter_backpressure, null);
            self.pending = output;
            return .accepted;
        }
        if (!self.rateAvailable(self.clock.now())) {
            for (commands[0..count]) |command| self.append(&output, command, .not_sent, .adapter_backpressure, null);
            self.pending = output;
            return .accepted;
        }
        if (!self.batchWithinNotional(commands[0..count])) {
            for (commands[0..count]) |command| self.append(&output, command, .not_sent, .unsupported_value, null);
            self.pending = output;
            return .accepted;
        }
        for (commands[0..count]) |command| if (self.validate(command)) |reason| {
            self.append(&output, command, .not_sent, reason, null);
        } else {
            self.dispatchOne(&output, command);
        };
        self.consumeRate(self.clock.now());
        self.pending = output;
        return .accepted;
    }
    fn drain(ptr: *anyopaque) venue.DrainError!?canonical.AdapterOutputBatch {
        const self: *BinanceVenueAdapter = @ptrCast(@alignCast(ptr));
        if (self.state == .idle) return error.NotStarted;
        const pending = self.pending;
        self.pending = null;
        if (pending != null) return pending;
        if (self.private_reconciler) |reconciler| if (reconciler.drain()) |private_output| {
            var output = private_output;
            if (self.pending_account_reconciliation != null) for (output.slice()) |record| if (record.event == .account_bootstrap_snapshot) {
                self.appendEvent(&output, self.pending_account_reconciliation.?, .{ .account_reconciliation_result = .{ .identity = self.pending_account_reconciliation.?, .complete = true, .status = .found_terminal } });
                self.pending_account_reconciliation = null;
                break;
            };
            return output;
        };
        return null;
    }
    fn stop(ptr: *anyopaque, _: venue.DrainDeadline) venue.StopError!void {
        const self: *BinanceVenueAdapter = @ptrCast(@alignCast(ptr));
        if (self.state == .idle) return error.NotStarted;
        if (self.pending != null or (self.private_reconciler != null and self.private_reconciler.?.hasPending())) return error.OutputPending;
        self.state = .stopped;
    }

    fn validate(self: *const BinanceVenueAdapter, command: canonical.OrderCommand) ?canonical.CanonicalRejectReason {
        const binding = self.binding orelse return .unsupported_value;
        if (self.hasUnknown() and command.operation != .cancel) return .venue_unavailable;
        if (command.exchange_account != binding.account) return .unsupported_value;
        if (command.capability_version != self.profile.version or command.rules_version != self.profile.rules_version or command.config_version != self.profile.config_version or command.adapter_session != binding.session) return .stale_version;
        if (command.dispatch_deadline_monotonic_ns <= self.clock.now()) return .deadline_expired;
        const instrument_rules = self.rules(command.instrument) orelse return .unsupported_instrument;
        if (command.operation != .cancel) {
            const quantity = command.quantity orelse return .unsupported_value;
            if (quantity.instrument != command.instrument or quantity.rules_version != command.rules_version or quantity.lots <= 0) return .unsupported_value;
        }
        if (command.operation == .amend and !self.profile.native_amend) return .capability_unsupported;
        if (command.operation != .place and (command.venue_order == null or command.venue_order.?.venue != binding.venue)) return .unsupported_value;
        if (command.order_type == .post_only and !self.profile.native_post_only) return .capability_unsupported;
        if (command.venue_reduce_only and (command.instrument != btc_usdt_linear or !self.profile.venue_reduce_only_linear)) return .capability_unsupported;
        if (command.operation == .place) {
            if (!self.profile.testnet_admission.permitsPlace()) return .venue_unavailable;
            const expected: canonical.TimeInForce = switch (command.order_type) {
                .market, .ioc => .immediate_or_cancel,
                .fok => .fill_or_kill,
                .post_only => .post_only,
                .limit => .good_til_canceled,
            };
            if (command.time_in_force != expected) return .unsupported_value;
            if (command.order_type == .market) {
                if (command.limit_price != null or command.market_protection_price == null) return .unsupported_value;
            } else if (command.limit_price == null or command.market_protection_price != null) return .unsupported_value;
            const price = command.limit_price orelse command.market_protection_price orelse return .unsupported_value;
            const notional = self.notionalMicros(command.quantity orelse return .unsupported_value, price, instrument_rules) orelse return .unsupported_value;
            if (notional > self.profile.testnet_admission.max_order_notional_usdt_micros) return .unsupported_value;
        }
        if (command.limit_price) |price| if (price.instrument != instrument_rules.identity or price.rules_version != command.rules_version or price.ticks <= 0) return .unsupported_value;
        return null;
    }
    fn notionalMicros(self: *const BinanceVenueAdapter, quantity: canonical.InstrumentQuantity, price_value: canonical.InstrumentPrice, instrument_rules: InstrumentRules) ?u64 {
        _ = self;
        if (quantity.lots <= 0 or price_value.ticks <= 0 or instrument_rules.lot_size.coefficient <= 0 or instrument_rules.tick_size.coefficient <= 0) return null;
        var numerator = std.math.mul(i128, quantity.lots, instrument_rules.lot_size.coefficient) catch return null;
        numerator = std.math.mul(i128, numerator, price_value.ticks) catch return null;
        numerator = std.math.mul(i128, numerator, instrument_rules.tick_size.coefficient) catch return null;
        const scale = std.math.add(u8, instrument_rules.lot_size.scale, instrument_rules.tick_size.scale) catch return null;
        if (scale <= 6) {
            const factor = powerOfTen(6 - scale) orelse return null;
            return std.math.cast(u64, std.math.mul(i128, numerator, factor) catch return null);
        }
        const divisor = powerOfTen(scale - 6) orelse return null;
        const adjusted = std.math.add(i128, numerator, divisor - 1) catch return null;
        return std.math.cast(u64, @divFloor(adjusted, divisor));
    }
    fn batchWithinNotional(self: *const BinanceVenueAdapter, commands: []const canonical.OrderCommand) bool {
        var total: u64 = 0;
        for (commands) |command| {
            if (command.operation != .place) continue;
            const instrument_rules = self.rules(command.instrument) orelse return false;
            const quantity = command.quantity orelse return false;
            const price = command.limit_price orelse command.market_protection_price orelse return false;
            const notional = self.notionalMicros(quantity, price, instrument_rules) orelse return false;
            total = std.math.add(u64, total, notional) catch return false;
            if (total > self.profile.testnet_admission.max_order_notional_usdt_micros) return false;
        }
        return true;
    }
    fn dispatchOne(self: *BinanceVenueAdapter, output: *canonical.AdapterOutputBatch, command: canonical.OrderCommand) void {
        if (command.operation == .place) if (self.private_reconciler) |reconciler|
            reconciler.registerOrder(command.identity, command.client_order_id, command.portfolio_reduce_only) catch {
                self.append(output, command, .not_sent, .adapter_backpressure, null);
                return;
            };
        const encoded = self.encode(command) catch {
            self.append(output, command, .not_sent, .unsupported_value, null);
            return;
        };
        const signature = self.auth.sign(encoded.timestamp_ns, encoded.body()) catch {
            self.append(output, command, .not_sent, .venue_unavailable, null);
            return;
        };
        const response = self.transport.submit(.{ .method = encoded.method, .path = encoded.path, .body = encoded.body(), .timestamp_ns = encoded.timestamp_ns, .signature = signature });
        const evidence = self.commitResponse(response) catch {
            self.append(output, command, .unknown, null, null);
            self.markUnknown(command.identity);
            return;
        };
        const result = classify(response.outcome, response.response);
        if (result == .unknown) self.markUnknown(command.identity);
        self.append(output, command, result, if (result == .not_sent) .other_venue_reject else null, evidence);
    }
    fn reconcileOrder(self: *BinanceVenueAdapter, request: canonical.OrderReconciliationRequest) venue.SendError!venue.SendResult {
        const binding = self.binding orelse return error.InvalidRequest;
        if (request.exchange_account != binding.account) return error.InvalidRequest;
        var output: canonical.AdapterOutputBatch = .{};
        self.appendEvent(&output, request.identity, .{ .reconciliation_started = request.identity });
        // A private status alone does not bind quantity, scope, and raw evidence.
        self.appendEvent(&output, request.identity, .{ .order_reconciliation_result = .{ .identity = request.identity, .complete = false, .status = .unresolved } });
        self.pending = output;
        return .accepted;
    }

    fn hasUnknown(self: *const BinanceVenueAdapter) bool {
        return self.unknown_overflow or self.unknown_count != 0;
    }
    fn markUnknown(self: *BinanceVenueAdapter, order: canonical.OrderIdentity) void {
        for (self.unknown_orders[0..self.unknown_count]) |existing| if (existing == order) return;
        if (self.unknown_count == self.unknown_orders.len) {
            self.unknown_overflow = true;
            return;
        }
        self.unknown_orders[self.unknown_count] = order;
        self.unknown_count += 1;
    }
    fn clearUnknown(self: *BinanceVenueAdapter, order: canonical.OrderIdentity) void {
        for (self.unknown_orders[0..self.unknown_count], 0..) |existing, index| if (existing == order) {
            self.unknown_count -= 1;
            self.unknown_orders[index] = self.unknown_orders[self.unknown_count];
            return;
        };
    }
    fn reconcileAccount(self: *BinanceVenueAdapter, request: canonical.AccountReconciliationRequest) venue.SendError!venue.SendResult {
        const binding = self.binding orelse return error.InvalidRequest;
        if (request.exchange_account != binding.account or request.expected_session != binding.session) return error.InvalidRequest;
        var output: canonical.AdapterOutputBatch = .{};
        self.appendEvent(&output, request.identity, .{ .account_reconciliation_started = request.identity });
        const reconciler = self.private_reconciler orelse {
            self.appendEvent(&output, request.identity, .{ .account_reconciliation_result = .{ .identity = request.identity, .complete = false, .status = .unresolved } });
            self.pending = output;
            return .accepted;
        };
        if (request.economic_boundary_utc_ns != null) {
            reconciler.beginEconomicReconciliation(request) catch {
                self.private_failed = true;
                return error.InvalidRequest;
            };
            self.pending = output;
            return .accepted;
        }
        if (request.economic_through_utc_ns != null) return error.InvalidRequest;
        if (reconciler.readiness().stage == .ready) {
            self.appendEvent(&output, request.identity, .{ .account_reconciliation_result = .{ .identity = request.identity, .complete = false, .status = .unresolved } });
            self.pending = output;
            return .accepted;
        }
        if (reconciler.readiness().stage == .buffering)
            reconciler.beginReconciliation(reconciler.readiness().raw_watermark) catch return error.InvalidRequest;
        self.pending_account_reconciliation = request.identity;
        self.pending = output;
        return .accepted;
    }
    fn commitResponse(self: *BinanceVenueAdapter, response: TransportResult) !?raw.RawEvidenceRef {
        const bytes = response.response orelse return if (response.outcome == .response) error.MissingResponse else null;
        if (bytes.len == 0 or bytes.len > 1024 * 1024 or bytes.len > std.math.maxInt(u32)) return error.InvalidResponse;
        var digest: [32]u8 = undefined;
        std.crypto.hash.sha2.Sha256.hash(bytes, &digest, .{});
        return try self.raw_sink.append(.{ .source_session = response.source_session, .receive_time_utc_ns = response.times.receive_time_utc_ns, .monotonic_time_ns = response.times.monotonic_time_ns, .wall_time_utc_ns = response.times.wall_time_utc_ns, .byte_len = @intCast(bytes.len), .sha256 = digest }, bytes);
    }
    fn encode(self: *const BinanceVenueAdapter, command: canonical.OrderCommand) !Encoded {
        const instrument_rules = self.rules(command.instrument) orelse return error.UnsupportedInstrument;
        const linear = command.instrument == btc_usdt_linear;
        const timestamp_ns = self.clock.now();
        var result: Encoded = .{
            .method = switch (command.operation) {
                .place => .post,
                .cancel => .delete,
                .amend => if (linear) .put else .post,
            },
            .path = switch (command.operation) {
                .place, .cancel => if (linear) "/fapi/v1/order" else "/api/v3/order",
                .amend => if (linear) "/fapi/v1/order" else "/api/v3/order/cancelReplace",
            },
            .timestamp_ns = timestamp_ns,
            .len = 0,
        };
        var quantity_buffer: [64]u8 = undefined;
        const quantity = if (command.quantity) |value| try decimalText(&quantity_buffer, value.lots, instrument_rules.lot_size) else "";
        var price_buffer: [64]u8 = undefined;
        const price = if (command.limit_price) |value| try decimalText(&price_buffer, value.ticks, instrument_rules.tick_size) else "";
        const side = switch (command.side) {
            .buy => "BUY",
            .sell => "SELL",
        };
        const kind = switch (command.order_type) {
            .market => "MARKET",
            .limit => "LIMIT",
            .post_only => if (linear) "LIMIT" else "LIMIT_MAKER",
            .fok => "LIMIT",
            .ioc => "LIMIT",
        };
        const tif = switch (command.time_in_force) {
            .good_til_canceled => "GTC",
            .immediate_or_cancel => "IOC",
            .fill_or_kill => "FOK",
            .post_only => "GTX",
        };
        var timestamp_text: [32]u8 = undefined;
        const timestamp = try std.fmt.bufPrint(&timestamp_text, "{d}", .{timestamp_ns});
        try appendForm(&result, "symbol", "BTCUSDT");
        switch (command.operation) {
            .place => {
                try appendForm(&result, "side", side);
                try appendForm(&result, "type", kind);
                if (!(command.order_type == .post_only and !linear)) try appendForm(&result, "timeInForce", tif);
                try appendForm(&result, "quantity", quantity);
                try appendForm(&result, "price", price);
                try appendForm(&result, "newClientOrderId", command.client_order_id.slice());
                if (linear and command.venue_reduce_only) try appendForm(&result, "reduceOnly", "true");
            },
            .cancel => {
                try appendForm(&result, "origClientOrderId", command.client_order_id.slice());
            },
            .amend => {
                if (!linear) try appendForm(&result, "cancelReplaceMode", "STOP_ON_FAILURE");
                try appendForm(&result, "side", side);
                if (!linear) try appendForm(&result, "type", kind);
                try appendForm(&result, "quantity", quantity);
                try appendForm(&result, "price", price);
                try appendForm(&result, "origClientOrderId", command.client_order_id.slice());
                if (!linear) try appendForm(&result, "newClientOrderId", command.client_order_id.slice());
            },
        }
        try appendForm(&result, "timestamp", timestamp);
        return result;
    }
    fn rules(self: *const BinanceVenueAdapter, identity: canonical.InstrumentIdentity) ?InstrumentRules {
        if (identity == self.profile.spot.identity) return self.profile.spot;
        if (identity == self.profile.linear.identity) return self.profile.linear;
        return null;
    }
    fn rateAvailable(self: *const BinanceVenueAdapter, now: u64) bool {
        return self.rate.count < self.profile.requests_per_window or now -| self.rate.window_start >= self.profile.window_ns;
    }
    fn consumeRate(self: *BinanceVenueAdapter, now: u64) void {
        if (now -| self.rate.window_start >= self.profile.window_ns) self.rate = .{ .window_start = now, .count = 1 } else self.rate.count += 1;
    }
    fn append(self: *BinanceVenueAdapter, output: *canonical.AdapterOutputBatch, command: canonical.OrderCommand, state: canonical.DispatchState, reason: ?canonical.CanonicalRejectReason, evidence: ?raw.RawEvidenceRef) void {
        const binding = self.binding orelse return;
        const sequence = self.next_event_sequence;
        self.next_event_sequence +%= 1;
        output.append(.{ .envelope = .{ .event_type = @intFromEnum(canonical.EventType.order_dispatch_result), .schema_version = canonical.schema_version, .identity = .{ .stream = binding.session, .sequence = sequence }, .source_fact_identity = command.identity, .scope = .account, .venue = binding.venue, .exchange_account = binding.account, .instrument = command.instrument, .source_stream = binding.session, .source_sequence = sequence, .adapter_session = binding.session, .times = .{ .monotonic_ns = self.clock.now() }, .raw_evidence = if (evidence) |value| .{ .stream = binding.session, .sequence = value.stream_sequence, .digest = value.sha256 } else .{ .stream = binding.session, .sequence = sequence, .digest = @splat(0) } }, .event = .{ .order_dispatch_result = .{ .command = command.identity, .state = state, .reason = reason } } }) catch return;
    }
    fn appendEvent(self: *BinanceVenueAdapter, output: *canonical.AdapterOutputBatch, source_fact_identity: u128, event: canonical.Payload) void {
        const binding = self.binding orelse return;
        const sequence = self.next_event_sequence;
        self.next_event_sequence +%= 1;
        output.append(.{ .envelope = .{ .event_type = @intFromEnum(canonical.eventType(event)), .schema_version = canonical.schema_version, .identity = .{ .stream = binding.session, .sequence = sequence }, .source_fact_identity = source_fact_identity, .scope = .account, .venue = binding.venue, .exchange_account = binding.account, .source_stream = binding.session, .source_sequence = sequence, .adapter_session = binding.session, .times = .{ .monotonic_ns = self.clock.now() }, .raw_evidence = .{ .stream = binding.session, .sequence = sequence, .digest = @splat(0) } }, .event = event }) catch return;
    }
};

fn appendForm(encoded: *Encoded, key: []const u8, value: []const u8) !void {
    if (value.len == 0) return;
    if (encoded.len + key.len + value.len + 2 > encoded.bytes.len) return error.RequestTooLarge;
    if (encoded.len != 0) {
        encoded.bytes[encoded.len] = '&';
        encoded.len += 1;
    }
    @memcpy(encoded.bytes[encoded.len..][0..key.len], key);
    encoded.len += key.len;
    encoded.bytes[encoded.len] = '=';
    encoded.len += 1;
    @memcpy(encoded.bytes[encoded.len..][0..value.len], value);
    encoded.len += value.len;
}

fn decimalText(buffer: *[64]u8, units: i128, increment: canonical.Decimal) ![]const u8 {
    const value = try std.math.mul(i128, units, increment.coefficient);
    const sign: []const u8 = if (value < 0) "-" else "";
    const absolute = if (value < 0) -value else value;
    const divisor = try pow10(increment.scale);
    const whole = try std.fmt.bufPrint(buffer, "{s}{d}", .{ sign, @divTrunc(absolute, divisor) });
    if (increment.scale == 0) return whole;
    var offset = whole.len;
    if (offset + 1 + increment.scale > buffer.len) return error.DecimalTooLong;
    buffer[offset] = '.';
    offset += 1;
    const remainder = @rem(absolute, divisor);
    var index: u8 = 0;
    while (index < increment.scale) : (index += 1) {
        const place = try pow10(increment.scale - index - 1);
        buffer[offset] = @intCast('0' + @mod(@divTrunc(remainder, place), 10));
        offset += 1;
    }
    return buffer[0..offset];
}
fn pow10(scale: u8) !i128 {
    var result: i128 = 1;
    var index: u8 = 0;
    while (index < scale) : (index += 1) result = try std.math.mul(i128, result, 10);
    return result;
}
fn powerOfTen(exponent: u8) ?i128 {
    var value: i128 = 1;
    for (0..exponent) |_| value = std.math.mul(i128, value, 10) catch return null;
    return value;
}

fn classify(outcome: TransportOutcome, response: ?[]const u8) canonical.DispatchState {
    if (outcome == .proven_before_send) return .not_sent;
    if (outcome == .write_or_response_uncertain) return .unknown;
    const bytes = response orelse return .unknown;
    const parsed = std.json.parseFromSlice(std.json.Value, std.heap.page_allocator, bytes, .{}) catch return .unknown;
    defer parsed.deinit();
    const object = switch (parsed.value) {
        .object => |value| value,
        else => return .unknown,
    };
    if (object.get("code")) |value| {
        const code = jsonInteger(value) orelse return .unknown;
        return if (code == 0) .submitted else .not_sent;
    }
    return if (object.get("orderId") != null) .submitted else .unknown;
}

fn jsonInteger(value: std.json.Value) ?i64 {
    return switch (value) {
        .integer => |number| number,
        .number_string, .string => |text| std.fmt.parseInt(i64, text, 10) catch null,
        else => null,
    };
}

const TestClock = struct {
    now: u64 = 1,
    fn interface(self: *TestClock) BinanceVenueAdapter.Clock {
        return .{ .ptr = self, .now_fn = nowFn };
    }
    fn nowFn(ptr: *anyopaque) u64 {
        return (@as(*@This(), @ptrCast(@alignCast(ptr)))).now;
    }
};
const TestAuth = struct {
    fn interface(self: *TestAuth) Authenticator {
        return .{ .ptr = self, .sign_fn = sign };
    }
    fn sign(_: *anyopaque, _: u64, _: []const u8) ![32]u8 {
        return @splat(1);
    }
};
const TestRaw = struct {
    calls: u64 = 0,
    fn interface(self: *TestRaw) raw.RawSink {
        return .{ .ptr = self, .append_fn = append };
    }
    fn append(ptr: *anyopaque, _: raw.RawIngressRecord, _: []const u8) raw.RawSinkError!u64 {
        const self: *@This() = @ptrCast(@alignCast(ptr));
        self.calls += 1;
        return self.calls;
    }
};
const TestTransport = struct {
    calls: u64 = 0,
    outcome: TransportOutcome = .response,
    response: ?[]const u8 = "{\"code\":0,\"orderId\":\"1\"}",
    fn interface(self: *TestTransport) Transport {
        return .{ .ptr = self, .submit_fn = submit };
    }
    fn submit(ptr: *anyopaque, request: SignedRequest) TransportResult {
        const self: *@This() = @ptrCast(@alignCast(ptr));
        self.calls += 1;
        std.debug.assert(request.signature[0] == 1 and request.body.len > 0);
        std.debug.assert(std.mem.indexOf(u8, request.body, "operation") == null);
        if (request.method == .post and std.mem.eql(u8, request.path, "/api/v3/order"))
            std.debug.assert(std.mem.indexOf(u8, request.body, "quantity=0.0001") != null);
        return .{ .outcome = self.outcome, .response = self.response, .source_session = 6, .times = .{ .receive_time_utc_ns = 2, .monotonic_time_ns = 3, .wall_time_utc_ns = 4 } };
    }
};
fn testProfile() CapabilityProfile {
    const rules = InstrumentRules{ .identity = btc_usdt_spot, .tick_size = .{ .coefficient = 1, .scale = 1 }, .lot_size = .{ .coefficient = 1, .scale = 4 } };
    return .{ .version = 7, .rules_version = 8, .config_version = 9, .session = 6, .spot = rules, .linear = .{ .identity = btc_usdt_linear, .tick_size = rules.tick_size, .lot_size = rules.lot_size }, .testnet_admission = .{ .explicit_enable = true, .endpoint_is_testnet = true, .credential_can_read = true, .credential_can_trade = true, .credential_can_withdraw = false } };
}
fn testCommand(identity: u128) !canonical.OrderCommand {
    return .{ .identity = identity, .exchange_account = 2, .instrument = btc_usdt_spot, .client_order_id = try canonical.ClientOrderId.init("BINANCE21"), .capability_version = 7, .rules_version = 8, .config_version = 9, .adapter_session = 6, .dispatch_deadline_monotonic_ns = 10, .quantity = .{ .instrument = btc_usdt_spot, .rules_version = 8, .lots = 1 }, .limit_price = .{ .instrument = btc_usdt_spot, .rules_version = 8, .ticks = 500_000 } };
}
fn privateRules(profile: CapabilityProfile) private.Rules {
    return .{
        .spot = .{ .identity = profile.spot.identity, .rules_version = profile.rules_version, .tick_size = profile.spot.tick_size, .lot_size = profile.spot.lot_size },
        .linear = .{ .identity = profile.linear.identity, .rules_version = profile.rules_version, .tick_size = profile.linear.tick_size, .lot_size = profile.linear.lot_size },
    };
}
fn startTest(adapter: venue.VenueAdapter) !void {
    try adapter.start(.{ .venue = 21, .asset_definitions = try contract.activatedTestAssets(), .environment = .demo, .exchange_account = 2, .adapter_session = 6, .request_capacity = 4, .output_capacity = 4 });
}

test "Binance canonical commands authenticate, raw-commit, and dispatch independently" {
    var clock = TestClock{};
    var auth = TestAuth{};
    var sink = TestRaw{};
    var transport = TestTransport{};
    var implementation = BinanceVenueAdapter.init(clock.interface(), testProfile(), auth.interface(), sink.interface(), transport.interface());
    const adapter = implementation.adapter();
    try startTest(adapter);
    var batch: canonical.OrderCommandBatch = .{};
    try batch.append(try testCommand(1));
    var second = try testCommand(2);
    second.operation = .cancel;
    second.venue_order = try canonical.VenueOrderRef.init(21, "order-2");
    try batch.append(second);
    try std.testing.expectEqual(venue.SendResult.accepted, try adapter.trySend(.{ .order_batch = batch }));
    const output = (try adapter.tryDrain()).?;
    try std.testing.expectEqual(@as(u8, 2), output.len);
    try std.testing.expectEqual(canonical.DispatchState.submitted, output.events[0].event.order_dispatch_result.state);
    try std.testing.expectEqual(@as(u64, 2), sink.calls);
    try std.testing.expectEqual(@as(u64, 2), transport.calls);
    try adapter.stop(.{ .monotonic_ns = 1 });
}

test "Binance parses response JSON instead of matching formatting" {
    try std.testing.expectEqual(canonical.DispatchState.not_sent, classify(.response, "{\"code\":-2010}"));
    try std.testing.expectEqual(canonical.DispatchState.unknown, classify(.response, "{\"code\":false}"));
    try std.testing.expectEqual(canonical.DispatchState.unknown, classify(.response, "not-json"));
    var clock = TestClock{};
    var auth = TestAuth{};
    var sink = TestRaw{};
    var transport = TestTransport{ .response = "{\"code\" : 0, \"orderId\" : \"1\"}" };
    var implementation = BinanceVenueAdapter.init(clock.interface(), testProfile(), auth.interface(), sink.interface(), transport.interface());
    const adapter = implementation.adapter();
    try startTest(adapter);
    _ = try adapter.trySend(.{ .order_command = try testCommand(1) });
    try std.testing.expectEqual(canonical.DispatchState.submitted, (try adapter.tryDrain()).?.events[0].event.order_dispatch_result.state);
}

test "Binance Unknown gate still permits cancel" {
    var clock = TestClock{};
    var auth = TestAuth{};
    var sink = TestRaw{};
    var transport = TestTransport{ .outcome = .write_or_response_uncertain, .response = null };
    var implementation = BinanceVenueAdapter.init(clock.interface(), testProfile(), auth.interface(), sink.interface(), transport.interface());
    const adapter = implementation.adapter();
    try startTest(adapter);
    _ = try adapter.trySend(.{ .order_command = try testCommand(1) });
    _ = try adapter.tryDrain();
    transport.outcome = .response;
    transport.response = "{\"orderId\":\"1\"}";
    var cancel = try testCommand(2);
    cancel.operation = .cancel;
    cancel.venue_order = try canonical.VenueOrderRef.init(21, "1");
    cancel.quantity = null;
    cancel.limit_price = null;
    _ = try adapter.trySend(.{ .order_command = cancel });
    try std.testing.expectEqual(canonical.DispatchState.submitted, (try adapter.tryDrain()).?.events[0].event.order_dispatch_result.state);
}

test "Binance clears only the reconciled Unknown order" {
    var clock = TestClock{};
    var auth = TestAuth{};
    var sink = TestRaw{};
    var transport = TestTransport{};
    var implementation = BinanceVenueAdapter.init(clock.interface(), testProfile(), auth.interface(), sink.interface(), transport.interface());
    implementation.markUnknown(1);
    implementation.markUnknown(2);
    implementation.clearUnknown(1);
    try std.testing.expect(implementation.hasUnknown());
    implementation.clearUnknown(2);
    try std.testing.expect(!implementation.hasUnknown());
}
test "Binance rejects stale and expired commands and latches unknown without retry" {
    var clock = TestClock{};
    var auth = TestAuth{};
    var sink = TestRaw{};
    var transport = TestTransport{ .outcome = .write_or_response_uncertain, .response = null };
    var implementation = BinanceVenueAdapter.init(clock.interface(), testProfile(), auth.interface(), sink.interface(), transport.interface());
    const adapter = implementation.adapter();
    try startTest(adapter);
    var stale = try testCommand(1);
    stale.config_version = 10;
    _ = try adapter.trySend(.{ .order_command = stale });
    const rejected = (try adapter.tryDrain()).?;
    try std.testing.expectEqual(canonical.CanonicalRejectReason.stale_version, rejected.events[0].event.order_dispatch_result.reason.?);
    _ = try adapter.trySend(.{ .order_command = try testCommand(2) });
    const unknown = (try adapter.tryDrain()).?;
    try std.testing.expectEqual(canonical.DispatchState.unknown, unknown.events[0].event.order_dispatch_result.state);
    _ = try adapter.trySend(.{ .order_command = try testCommand(3) });
    const blocked = (try adapter.tryDrain()).?;
    try std.testing.expectEqual(canonical.DispatchState.not_sent, blocked.events[0].event.order_dispatch_result.state);
    try std.testing.expectEqual(@as(u64, 1), transport.calls);
}

test "Binance Testnet sends require explicit no-withdraw admission and bounded notional" {
    var clock = TestClock{};
    var auth = TestAuth{};
    var sink = TestRaw{};
    var transport = TestTransport{};
    var profile = testProfile();
    profile.testnet_admission.explicit_enable = false;
    var implementation = BinanceVenueAdapter.init(clock.interface(), profile, auth.interface(), sink.interface(), transport.interface());
    const adapter = implementation.adapter();
    try startTest(adapter);

    _ = try adapter.trySend(.{ .order_command = try testCommand(1) });
    const disabled = (try adapter.tryDrain()).?;
    try std.testing.expectEqual(canonical.CanonicalRejectReason.venue_unavailable, disabled.events[0].event.order_dispatch_result.reason.?);
    try std.testing.expectEqual(@as(u64, 0), transport.calls);

    implementation.profile.testnet_admission.explicit_enable = true;
    implementation.profile.testnet_admission.credential_can_withdraw = true;
    _ = try adapter.trySend(.{ .order_command = try testCommand(2) });
    const withdrawal_capable = (try adapter.tryDrain()).?;
    try std.testing.expectEqual(canonical.CanonicalRejectReason.venue_unavailable, withdrawal_capable.events[0].event.order_dispatch_result.reason.?);
    try std.testing.expectEqual(@as(u64, 0), transport.calls);

    implementation.profile.testnet_admission.credential_can_withdraw = false;
    implementation.profile.testnet_admission.max_order_notional_usdt_micros = 4_999_999;
    _ = try adapter.trySend(.{ .order_command = try testCommand(3) });
    const excessive = (try adapter.tryDrain()).?;
    try std.testing.expectEqual(canonical.CanonicalRejectReason.unsupported_value, excessive.events[0].event.order_dispatch_result.reason.?);
    try std.testing.expectEqual(@as(u64, 0), transport.calls);

    implementation.profile.testnet_admission.max_order_notional_usdt_micros = 9_999_999;
    var batch: canonical.OrderCommandBatch = .{};
    try batch.append(try testCommand(4));
    try batch.append(try testCommand(5));
    _ = try adapter.trySend(.{ .order_batch = batch });
    const aggregate_excess = (try adapter.tryDrain()).?;
    try std.testing.expectEqual(@as(u8, 2), aggregate_excess.len);
    try std.testing.expectEqual(canonical.CanonicalRejectReason.unsupported_value, aggregate_excess.events[0].event.order_dispatch_result.reason.?);
    try std.testing.expectEqual(@as(u64, 0), transport.calls);
    try adapter.stop(.{ .monotonic_ns = 1 });
}

test "Binance validates TIF, post-only, reduce-only, amend, and deadline before transport" {
    var clock = TestClock{};
    var auth = TestAuth{};
    var sink = TestRaw{};
    var transport = TestTransport{};
    var capability_profile = testProfile();
    capability_profile.native_post_only = false;
    var implementation = BinanceVenueAdapter.init(clock.interface(), capability_profile, auth.interface(), sink.interface(), transport.interface());
    const adapter = implementation.adapter();
    try startTest(adapter);
    var post = try testCommand(1);
    post.order_type = .post_only;
    post.time_in_force = .post_only;
    _ = try adapter.trySend(.{ .order_command = post });
    try std.testing.expectEqual(canonical.CanonicalRejectReason.capability_unsupported, (try adapter.tryDrain()).?.events[0].event.order_dispatch_result.reason.?);
    var amend = try testCommand(2);
    amend.operation = .amend;
    _ = try adapter.trySend(.{ .order_command = amend });
    try std.testing.expectEqual(canonical.CanonicalRejectReason.unsupported_value, (try adapter.tryDrain()).?.events[0].event.order_dispatch_result.reason.?);
    var expired = try testCommand(3);
    expired.dispatch_deadline_monotonic_ns = 1;
    _ = try adapter.trySend(.{ .order_command = expired });
    try std.testing.expectEqual(canonical.CanonicalRejectReason.deadline_expired, (try adapter.tryDrain()).?.events[0].event.order_dispatch_result.reason.?);
    try std.testing.expectEqual(@as(u64, 0), transport.calls);
}
test "Binance required capabilities stay unverified without Testnet evidence" {
    const profile = testProfile();
    try std.testing.expect(profile.native_amend and profile.native_post_only);
    try std.testing.expect(!profile.verified_native_amend);
    try std.testing.expect(!profile.verified_native_post_only);
    try std.testing.expect(!profile.verified_bounded_batch);
    try std.testing.expectEqual(@import("production_contract.zig").Qualification.not_run, profile.qualification);
}

test "Binance spot and linear encode official methods and paths without operation" {
    var clock = TestClock{};
    var auth = TestAuth{};
    var sink = TestRaw{};
    var transport = TestTransport{};
    var implementation = BinanceVenueAdapter.init(clock.interface(), testProfile(), auth.interface(), sink.interface(), transport.interface());
    const spot_place = try implementation.encode(try testCommand(1));
    try std.testing.expectEqual(HttpMethod.post, spot_place.method);
    try std.testing.expectEqualStrings("/api/v3/order", spot_place.path);
    try std.testing.expect(std.mem.indexOf(u8, spot_place.body(), "operation") == null);
    try std.testing.expect(std.mem.indexOf(u8, spot_place.body(), "symbol=BTCUSDT") != null);
    try std.testing.expect(std.mem.indexOf(u8, spot_place.body(), "newClientOrderId=") != null);

    var spot_cancel = try testCommand(2);
    spot_cancel.operation = .cancel;
    const encoded_cancel = try implementation.encode(spot_cancel);
    try std.testing.expectEqual(HttpMethod.delete, encoded_cancel.method);
    try std.testing.expectEqualStrings("/api/v3/order", encoded_cancel.path);
    try std.testing.expect(std.mem.indexOf(u8, encoded_cancel.body(), "origClientOrderId=") != null);

    var spot_amend = try testCommand(3);
    spot_amend.operation = .amend;
    const encoded_amend = try implementation.encode(spot_amend);
    try std.testing.expectEqual(HttpMethod.post, encoded_amend.method);
    try std.testing.expectEqualStrings("/api/v3/order/cancelReplace", encoded_amend.path);
    try std.testing.expect(std.mem.indexOf(u8, encoded_amend.body(), "cancelReplaceMode=STOP_ON_FAILURE") != null);

    var linear_place = try testCommand(4);
    linear_place.instrument = btc_usdt_linear;
    linear_place.quantity = .{ .instrument = btc_usdt_linear, .rules_version = 8, .lots = 1 };
    linear_place.limit_price = .{ .instrument = btc_usdt_linear, .rules_version = 8, .ticks = 500_000 };
    const encoded_linear = try implementation.encode(linear_place);
    try std.testing.expectEqual(HttpMethod.post, encoded_linear.method);
    try std.testing.expectEqualStrings("/fapi/v1/order", encoded_linear.path);

    var linear_amend = linear_place;
    linear_amend.operation = .amend;
    const encoded_linear_amend = try implementation.encode(linear_amend);
    try std.testing.expectEqual(HttpMethod.put, encoded_linear_amend.method);
    try std.testing.expectEqualStrings("/fapi/v1/order", encoded_linear_amend.path);
    try std.testing.expect(std.mem.indexOf(u8, encoded_linear_amend.body(), "operation") == null);
}

test "Binance implementation exercises the shared VenueAdapter contract" {
    var clock = TestClock{};
    var auth = TestAuth{};
    var sink = TestRaw{};
    var transport = TestTransport{};
    var implementation = BinanceVenueAdapter.init(clock.interface(), testProfile(), auth.interface(), sink.interface(), transport.interface());
    try contract.exerciseWith(implementation.adapter(), .{ .venue = 21, .asset_definitions = try contract.activatedTestAssets(), .environment = .demo, .exchange_account = 2, .adapter_session = 6, .request_capacity = 4, .output_capacity = 4 }, .{ .order_command = try testCommand(1) });
}

test "Binance private bootstrap drains through the shared VenueAdapter seam" {
    var clock = TestClock{};
    var auth = TestAuth{};
    var sink = TestRaw{};
    var transport = TestTransport{};
    const profile = testProfile();
    var reconciler = private.Reconciler.init(sink.interface(), privateRules(profile));
    var implementation = BinanceVenueAdapter.init(clock.interface(), profile, auth.interface(), sink.interface(), transport.interface());
    implementation.attachPrivateReconciler(&reconciler);
    const adapter = implementation.adapter();
    try startTest(adapter);
    try implementation.beginPrivateReconciliation();
    try reconciler.registerOrder(9, try canonical.ClientOrderId.init("RWN-9"), false);
    const times = raw.Times{ .receive_time_utc_ns = 1, .monotonic_time_ns = 2, .wall_time_utc_ns = 3 };
    _ = try implementation.ingestPrivate(std.testing.allocator, .rest_spot_account, .{ .final = true }, times, "{\"balances\":[]}");
    _ = try implementation.ingestPrivate(std.testing.allocator, .rest_orders, .{ .final = true }, times, "[]");
    _ = try implementation.ingestPrivate(std.testing.allocator, .rest_fills, .{ .final = true }, times, "[]");
    const output = (try adapter.tryDrain()).?;
    try std.testing.expectEqual(@as(u8, 1), output.len);
    try std.testing.expect(output.events[0].event == .account_bootstrap_snapshot);
    _ = try adapter.trySend(.{ .order_reconciliation = .{ .identity = 99, .exchange_account = 2, .order = 9 } });
    const resolved = (try adapter.tryDrain()).?;
    try std.testing.expectEqual(@as(u8, 2), resolved.len);
    try std.testing.expect(output.events[0].envelope.identity.stream != resolved.events[0].envelope.identity.stream);
    try std.testing.expectEqual(canonical.ReconciliationStatus.unresolved, resolved.events[1].event.order_reconciliation_result.status);
    _ = try adapter.trySend(.{ .order_reconciliation = .{ .identity = 100, .exchange_account = 2, .order = 9 } });
    const absent = (try adapter.tryDrain()).?;
    try std.testing.expectEqual(canonical.ReconciliationStatus.unresolved, absent.events[1].event.order_reconciliation_result.status);
}

test "Binance private partial fills cross the shared recovery contract" {
    var clock = TestClock{};
    var auth = TestAuth{};
    var sink = TestRaw{};
    var transport = TestTransport{};
    const profile = testProfile();
    var reconciler = private.Reconciler.init(sink.interface(), privateRules(profile));
    var implementation = BinanceVenueAdapter.init(clock.interface(), profile, auth.interface(), sink.interface(), transport.interface());
    implementation.attachPrivateReconciler(&reconciler);
    const adapter = implementation.adapter();
    try startTest(adapter);
    try implementation.beginPrivateReconciliation();
    try reconciler.registerOrder(1, try canonical.ClientOrderId.init("RWN-1"), false);
    const times = raw.Times{ .receive_time_utc_ns = 1, .monotonic_time_ns = 2, .wall_time_utc_ns = 3 };
    const first = "{\"e\":\"executionReport\",\"E\":\"1\",\"s\":\"BTCUSDT\",\"c\":\"RWN-1\",\"S\":\"BUY\",\"o\":\"LIMIT\",\"f\":\"GTC\",\"q\":\"0.0100\",\"p\":\"50000.0\",\"X\":\"PARTIALLY_FILLED\",\"i\":\"42\",\"l\":\"0.0040\",\"z\":\"0.0040\",\"L\":\"50000.0\",\"n\":\"-0.000001\",\"N\":\"BTC\",\"T\":\"2\",\"t\":\"77\",\"m\":true}";
    const second = "{\"e\":\"executionReport\",\"E\":\"2\",\"s\":\"BTCUSDT\",\"c\":\"RWN-1\",\"S\":\"BUY\",\"o\":\"LIMIT\",\"f\":\"GTC\",\"q\":\"0.0100\",\"p\":\"50000.0\",\"X\":\"FILLED\",\"i\":\"42\",\"l\":\"0.0060\",\"z\":\"0.0100\",\"L\":\"50000.0\",\"n\":\"-0.000001\",\"N\":\"BTC\",\"T\":\"3\",\"t\":\"78\",\"m\":true}";
    _ = try implementation.ingestPrivate(std.testing.allocator, .ws, null, times, first);
    _ = try implementation.ingestPrivate(std.testing.allocator, .ws, null, times, second);
    _ = try implementation.ingestPrivate(std.testing.allocator, .ws, null, times, second);
    var equivalent: [2048]u8 = undefined;
    const count = std.mem.replace(u8, second, "0.0100", "+000.0100000000000000000000000000000000000000000000000", &equivalent);
    try std.testing.expectEqual(@as(usize, 2), count);
    const len = second.len + count * ("+000.0100000000000000000000000000000000000000000000000".len - "0.0100".len);
    _ = try implementation.ingestPrivate(std.testing.allocator, .ws, null, times, equivalent[0..len]);
    _ = try implementation.ingestPrivate(std.testing.allocator, .rest_spot_account, .{ .final = true }, times, "{\"balances\":[]}");
    _ = try implementation.ingestPrivate(std.testing.allocator, .rest_orders, .{ .final = true }, times, "[]");
    _ = try implementation.ingestPrivate(std.testing.allocator, .rest_fills, .{ .final = true }, times, "[]");
    const output = (try adapter.tryDrain()).?;
    try contract.exerciseFillRecovery(output.slice(), .{ .venue = 21, .exchange_account = 2, .adapter_session = 6 });
    try std.testing.expect((try adapter.tryDrain()) == null);
    try std.testing.expectError(error.InvalidRequest, adapter.trySend(.{ .order_reconciliation = .{ .identity = 99, .exchange_account = 3, .order = 1 } }));
    var overflowing: [2048]u8 = undefined;
    const overflow_count = std.mem.replace(u8, second, "-0.000001", "-170141183460469231731687303715884105728", &overflowing);
    try std.testing.expectEqual(@as(usize, 1), overflow_count);
    const overflow_len = second.len + "-170141183460469231731687303715884105728".len - "-0.000001".len;
    try std.testing.expectError(error.DecimalScalingOverflow, implementation.ingestPrivate(std.testing.allocator, .ws, null, times, overflowing[0..overflow_len]));
    const fault = (try adapter.tryDrain()) orelse return error.MissingEconomicFault;
    try std.testing.expectEqual(@as(u8, 1), fault.len);
    try std.testing.expectEqual(canonical.EconomicFaultReason.overflow, fault.events[0].event.economic_fault.reason);
    try contract.exerciseEconomicFaultRecovery(fault);
    try std.testing.expectEqual(venue.SendResult.backpressure, try adapter.trySend(.{ .order_command = try testCommand(2) }));
    try implementation.beginPrivateSession();
    try std.testing.expectEqual(venue.SendResult.backpressure, try adapter.trySend(.{ .order_command = try testCommand(2) }));
    try std.testing.expectEqual(@as(u64, 0), transport.calls);
}

test "Binance activated precision converts private fills without trading authority" {
    var clock = TestClock{};
    var auth = TestAuth{};
    var sink = TestRaw{};
    var transport = TestTransport{};
    const profile = testProfile();
    var reconciler = private.Reconciler.init(sink.interface(), privateRules(profile));
    var implementation = BinanceVenueAdapter.init(clock.interface(), profile, auth.interface(), sink.interface(), transport.interface());
    implementation.attachPrivateReconciler(&reconciler);
    const adapter = implementation.adapter();
    try adapter.start(.{ .asset_definitions = try contract.activatedTestAssetsWithScales(12, 9), .venue = 21, .environment = .demo, .exchange_account = 2, .adapter_session = 6, .request_capacity = 4, .output_capacity = 4 });
    try implementation.beginPrivateReconciliation();
    try reconciler.registerOrder(1, try canonical.ClientOrderId.init("RWN-1"), false);
    const times = raw.Times{ .receive_time_utc_ns = 1, .monotonic_time_ns = 2, .wall_time_utc_ns = 3 };
    const first = "{\"e\":\"executionReport\",\"E\":\"1\",\"s\":\"BTCUSDT\",\"c\":\"RWN-1\",\"S\":\"BUY\",\"o\":\"LIMIT\",\"f\":\"GTC\",\"q\":\"0.0100\",\"p\":\"50000.0\",\"X\":\"PARTIALLY_FILLED\",\"i\":\"42\",\"l\":\"0.0040\",\"z\":\"0.0040\",\"L\":\"50000.0\",\"n\":\"-0.000000001\",\"N\":\"BTC\",\"T\":\"2\",\"t\":\"77\",\"m\":true}";
    const second = "{\"e\":\"executionReport\",\"E\":\"2\",\"s\":\"BTCUSDT\",\"c\":\"RWN-1\",\"S\":\"BUY\",\"o\":\"LIMIT\",\"f\":\"GTC\",\"q\":\"0.0100\",\"p\":\"50000.0\",\"X\":\"FILLED\",\"i\":\"42\",\"l\":\"0.0060\",\"z\":\"0.0100\",\"L\":\"50000.0\",\"n\":\"-0.000000001\",\"N\":\"BTC\",\"T\":\"3\",\"t\":\"78\",\"m\":true}";
    _ = try implementation.ingestPrivate(std.testing.allocator, .ws, null, times, first);
    _ = try implementation.ingestPrivate(std.testing.allocator, .ws, null, times, second);
    _ = try implementation.ingestPrivate(std.testing.allocator, .ws, null, times, second);
    var equivalent: [2048]u8 = undefined;
    const count = std.mem.replace(u8, second, "0.0100", "+000.0100000000000000000000000000000000000000000000000", &equivalent);
    try std.testing.expectEqual(@as(usize, 2), count);
    const len = second.len + count * ("+000.0100000000000000000000000000000000000000000000000".len - "0.0100".len);
    _ = try implementation.ingestPrivate(std.testing.allocator, .ws, null, times, equivalent[0..len]);
    _ = try implementation.ingestPrivate(std.testing.allocator, .rest_spot_account, .{ .final = true }, times, "{\"balances\":[]}");
    _ = try implementation.ingestPrivate(std.testing.allocator, .rest_orders, .{ .final = true }, times, "[]");
    _ = try implementation.ingestPrivate(std.testing.allocator, .rest_fills, .{ .final = true }, times, "[]");
    const output = (try adapter.tryDrain()).?;
    var fills: usize = 0;
    for (output.slice()) |record| if (record.event == .fill) {
        fills += 1;
        const fill = record.event.fill;
        try std.testing.expectEqual(@as(i128, 1), if (fill.rebate) |rebate| rebate.atoms else fill.fee.?.atoms);
    };
    try std.testing.expectEqual(@as(usize, 2), fills);
    try std.testing.expectEqual(venue.SendResult.backpressure, try adapter.trySend(.{ .order_command = try testCommand(2) }));
    try std.testing.expectEqual(@as(u64, 0), transport.calls);
}

test "Binance missing activation retains raw fault and stops risk across reconnect" {
    var clock = TestClock{};
    var auth = TestAuth{};
    var sink = TestRaw{};
    var transport = TestTransport{};
    const profile = testProfile();
    var reconciler = private.Reconciler.init(sink.interface(), privateRules(profile));
    var implementation = BinanceVenueAdapter.init(clock.interface(), profile, auth.interface(), sink.interface(), transport.interface());
    implementation.attachPrivateReconciler(&reconciler);
    const adapter = implementation.adapter();
    try adapter.start(.{ .venue = 21, .environment = .demo, .exchange_account = 2, .adapter_session = 6, .request_capacity = 4, .output_capacity = 4 });
    try implementation.beginPrivateReconciliation();
    try reconciler.registerOrder(1, try canonical.ClientOrderId.init("RWN-1"), false);
    const times = raw.Times{ .receive_time_utc_ns = 1, .monotonic_time_ns = 2, .wall_time_utc_ns = 3 };
    const first = "{\"e\":\"executionReport\",\"E\":\"1\",\"s\":\"BTCUSDT\",\"c\":\"RWN-1\",\"S\":\"BUY\",\"o\":\"LIMIT\",\"f\":\"GTC\",\"q\":\"0.0100\",\"p\":\"50000.0\",\"X\":\"PARTIALLY_FILLED\",\"i\":\"42\",\"l\":\"0.0040\",\"z\":\"0.0040\",\"L\":\"50000.0\",\"n\":\"-0.000001\",\"N\":\"BTC\",\"T\":\"2\",\"t\":\"77\",\"m\":true}";
    try std.testing.expectError(error.UnsupportedAsset, implementation.ingestPrivate(std.testing.allocator, .ws, null, times, first));
    const fault = (try adapter.tryDrain()) orelse return error.MissingEconomicFault;
    try std.testing.expectEqual(canonical.EconomicFaultReason.unknown_asset, fault.events[0].event.economic_fault.reason);
    try contract.exerciseEconomicFaultRecovery(fault);
    try std.testing.expectEqual(venue.SendResult.backpressure, try adapter.trySend(.{ .order_command = try testCommand(2) }));
    try implementation.beginPrivateSession();
    try std.testing.expectEqual(venue.SendResult.backpressure, try adapter.trySend(.{ .order_command = try testCommand(2) }));
    try std.testing.expectEqual(@as(u64, 1), sink.calls);
    try std.testing.expectEqual(@as(u64, 0), transport.calls);
}

test "Binance activated amount range retains raw fault and stops risk" {
    var clock = TestClock{};
    var auth = TestAuth{};
    var sink = TestRaw{};
    var transport = TestTransport{};
    const profile = testProfile();
    var reconciler = private.Reconciler.init(sink.interface(), privateRules(profile));
    var implementation = BinanceVenueAdapter.init(clock.interface(), profile, auth.interface(), sink.interface(), transport.interface());
    implementation.attachPrivateReconciler(&reconciler);
    const adapter = implementation.adapter();
    var configured: @import("trading_shard.zig").TradingShard = .{};
    var definitions = @import("asset_registry.zig").testDefinitions(6, 8);
    definitions[1].max_single_atoms = 1;
    definitions[1].max_balance_atoms = 1;
    definitions[1].max_cumulative_atoms = 1;
    for (definitions) |definition|
        _ = try configured.apply(.{ .core = .{ .identity = definition.asset, .payload = .{ .asset_definition_activated = definition } } });
    try adapter.start(.{ .asset_definitions = configured.activatedAssets(), .venue = 21, .environment = .demo, .exchange_account = 2, .adapter_session = 6, .request_capacity = 4, .output_capacity = 4 });
    try implementation.beginPrivateReconciliation();
    try reconciler.registerOrder(1, try canonical.ClientOrderId.init("RWN-1"), false);
    const times = raw.Times{ .receive_time_utc_ns = 1, .monotonic_time_ns = 2, .wall_time_utc_ns = 3 };
    const first = "{\"e\":\"executionReport\",\"E\":\"1\",\"s\":\"BTCUSDT\",\"c\":\"RWN-1\",\"S\":\"BUY\",\"o\":\"LIMIT\",\"f\":\"GTC\",\"q\":\"0.0100\",\"p\":\"50000.0\",\"X\":\"PARTIALLY_FILLED\",\"i\":\"42\",\"l\":\"0.0040\",\"z\":\"0.0040\",\"L\":\"50000.0\",\"n\":\"-0.000001\",\"N\":\"BTC\",\"T\":\"2\",\"t\":\"77\",\"m\":true}";
    try std.testing.expectError(error.AssetAmountOutOfRange, implementation.ingestPrivate(std.testing.allocator, .ws, null, times, first));
    const fault = (try adapter.tryDrain()) orelse return error.MissingEconomicFault;
    try std.testing.expectEqual(canonical.EconomicFaultReason.overflow, fault.events[0].event.economic_fault.reason);
    try contract.exerciseEconomicFaultRecovery(fault);
    try std.testing.expectEqual(venue.SendResult.backpressure, try adapter.trySend(.{ .order_command = try testCommand(2) }));
    try implementation.beginPrivateSession();
    try std.testing.expectEqual(venue.SendResult.backpressure, try adapter.trySend(.{ .order_command = try testCommand(2) }));
    try std.testing.expectEqual(@as(u64, 1), sink.calls);
    try std.testing.expectEqual(@as(u64, 0), transport.calls);
}

test "Binance scoped Spot snapshots stay unresolved without combined product and bill proof through Owner recovery" {
    const demo = @import("demo_authority.zig");
    const durable = @import("durable_store.zig");
    const ingress = @import("raw_ingress.zig");
    const fixture = @import("trading_shard_fixture.zig");
    const Sink = struct {
        raw: *ingress.DurableSink,
        fn append(ptr: *anyopaque, record: raw.RawIngressRecord, bytes: []const u8) raw.RawSinkError!u64 {
            const self: *@This() = @ptrCast(@alignCast(ptr));
            return (try self.raw.interface().append(.{ .source_session = record.source_session, .receive_time_utc_ns = record.receive_time_utc_ns, .monotonic_time_ns = record.monotonic_time_ns, .wall_time_utc_ns = record.wall_time_utc_ns, .byte_len = record.byte_len, .sha256 = record.sha256 }, bytes)).stream_sequence;
        }
    };
    const allocator = std.testing.allocator;
    const trading = @import("trading_shard.zig");
    const boundary: u64 = 1_800_000_000_000_000_000;
    for ([_]enum { zero, nonempty, missing_target, missing_range }{ .zero, .nonempty, .missing_target, .missing_range }) |case| {
        const memory = try allocator.create(durable.MemoryAdapter);
        defer allocator.destroy(memory);
        memory.* = .initWithAllocator(allocator);
        defer memory.deinit();
        const stream: durable.StreamIdentity = .{ .domain = .decision_log, .id = 91 };
        const owner = try allocator.create(demo.Owner);
        defer allocator.destroy(owner);
        owner.* = try demo.Owner.bootstrap(memory.interface(), undefined, stream);
        const assets = @import("asset_registry.zig").testDefinitions(12, 9);
        for (assets) |definition| _ = try owner.apply(.{ .core = .{ .identity = definition.asset, .payload = .{ .asset_definition_activated = definition } } });
        for (fixture.genesisEvents(.{ .strategy_identity = 40, .config_version = 1, .activation_identity = 50, .activation_barrier = 1 }, .cash)) |original| {
            var event = original;
            switch (event.core.payload) {
                .asset_definition_activated => |*definition| definition.* = if (definition.asset == 1) assets[0] else assets[1],
                .instrument_rules_activated => |*rules| {
                    if (rules.instrument_identity == fixture.spot_instrument) continue;
                    rules.instrument_identity = btc_usdt_spot;
                    rules.quantity_denominator = 10_000_000;
                    rules.quantity_numerator = 2;
                    rules.venue = 21;
                },
                .instrument_trading_authorization => |*authorization| {
                    if (authorization.instrument == fixture.spot_instrument) continue;
                    authorization.instrument = btc_usdt_spot;
                },
                .margin_rules_activated => |*margin| {
                    if (margin.instrument == fixture.spot_instrument) continue;
                    margin.instrument = btc_usdt_spot;
                    margin.native_settlement_atoms = true;
                    margin.price_tick_atoms = 250_000_000_000;
                },
                .mark_price => |*mark| {
                    if (mark.instrument == fixture.spot_instrument) continue;
                    mark.instrument = btc_usdt_spot;
                    mark.price_atoms = 50_000_000_000_000_000;
                },
                .exchange_balance => |*balance| balance.cash_atoms = 100_000_000_000_000,
                .opening_balance => |*balance| {
                    balance.cash_atoms = 100_000_000_000_000;
                    event.core.source_time = boundary;
                    event.core.time_presence.source = true;
                },
                .portfolio_transfer => |*transfer| transfer.amount_atoms = 90_000_000_000_000,
                .risk_lease_granted => |*lease| lease.amount_atoms = 80_000_000_000_000,
                else => {},
            }
            _ = try owner.apply(event);
        }
        try owner.sealBootstrap();
        var durable_raw = try ingress.DurableSink.init(memory.interface(), undefined, .{ .domain = .raw_ingress, .id = 1 });
        var sink: Sink = .{ .raw = &durable_raw };
        const raw_sink: raw.RawSink = .{ .ptr = &sink, .append_fn = Sink.append };
        var clock = TestClock{};
        var auth = TestAuth{};
        var transport = TestTransport{};
        var profile = testProfile();
        profile.session = 1;
        profile.rules_version = 1;
        profile.spot.tick_size = .{ .coefficient = 25, .scale = 2 };
        profile.spot.lot_size = .{ .coefficient = 2, .scale = 7 };
        var implementation = BinanceVenueAdapter.init(clock.interface(), profile, auth.interface(), raw_sink, transport.interface());
        var reconciler = private.Reconciler.init(raw_sink, .{ .spot = .{ .identity = btc_usdt_spot, .rules_version = 1, .tick_size = profile.spot.tick_size, .lot_size = profile.spot.lot_size }, .linear = .{ .identity = btc_usdt_linear, .rules_version = 1, .tick_size = profile.linear.tick_size, .lot_size = profile.linear.lot_size } });
        implementation.attachPrivateReconciler(&reconciler);
        const adapter = implementation.adapter();
        try adapter.start(.{ .venue = 21, .exchange_account = 2, .adapter_session = 1, .environment = .demo, .request_capacity = 4, .output_capacity = 4, .asset_definitions = owner.shard.activatedAssets(), .instrument_definitions = owner.shard.instrument_registry, .native_settlement_atoms = true });
        try implementation.beginPrivateReconciliation();
        const times: raw.Times = .{ .receive_time_utc_ns = boundary + 1, .monotonic_time_ns = 1, .wall_time_utc_ns = boundary + 2 };
        const target = "/api/v3/account?timestamp=1800000000000";
        const account = "{\"accountType\":\"SPOT\",\"updateTime\":1800000000000,\"balances\":[{\"asset\":\"USDT\",\"free\":\"99\",\"locked\":\"1\"},{\"asset\":\"BTC\",\"free\":\"0\",\"locked\":\"0\"}]}";
        _ = try implementation.ingestPrivate(std.testing.allocator, .rest_spot_account, .{ .final = true, .request_target = target }, times, account);
        _ = try implementation.ingestPrivate(std.testing.allocator, .rest_orders, .{ .final = true }, times, "[]");
        _ = try implementation.ingestPrivate(std.testing.allocator, .rest_fills, .{ .final = true }, times, "[]");
        while (try adapter.tryDrain()) |batch| try owner.applyAdapterBatch(batch);
        const before = owner.shard.economicSummary();
        try std.testing.expectEqual(venue.SendResult.accepted, try adapter.trySend(.{ .account_reconciliation = .{ .identity = 300, .exchange_account = 2, .expected_session = 1, .economic_boundary_utc_ns = if (case == .missing_range) null else boundary, .economic_through_utc_ns = if (case == .nonempty) boundary + 1_000_000 else null } }));
        const started = (try adapter.tryDrain()).?;
        var found = false;
        if (case == .missing_range) for (started.slice()) |record| {
            if (record.event != .account_reconciliation_result) continue;
            found = true;
            try std.testing.expect(!record.event.account_reconciliation_result.complete);
            try std.testing.expect(record.event.account_reconciliation_result.status == .unresolved);
            try std.testing.expect(record.event.account_reconciliation_result.account_economics == null);
        };
        try owner.applyAdapterBatch(started);
        _ = try implementation.ingestPrivate(std.testing.allocator, .rest_spot_account, .{ .final = true, .request_target = if (case == .missing_target) null else target }, times, account);
        while (try adapter.tryDrain()) |batch| {
            for (batch.slice()) |record| if (record.event == .account_reconciliation_result) {
                found = true;
                const result = record.event.account_reconciliation_result;
                try std.testing.expect(!result.complete and result.status == .unresolved);
                const proof = result.account_economics.?;
                try std.testing.expectEqual(@as(i128, 100_000_000_000_000), proof.balances[0].atoms);
                try std.testing.expectEqual(@as(u64, 1), proof.asset_versions[0]);
                try std.testing.expectEqual(boundary, proof.from_utc_ns);
                try std.testing.expectEqual(boundary, proof.through_utc_ns);
                try std.testing.expect(!proof.bills_complete);
                try std.testing.expectEqual(@as(u8, if (case == .missing_target) 0 else 1), proof.query_count);
            };
            try owner.applyAdapterBatch(batch);
        }
        try std.testing.expect(found);
        try std.testing.expectEqualDeep(before, owner.shard.economicSummary());
        try std.testing.expect(!owner.shard.operational_state.effectiveTradingAuthority());
        if (case != .missing_range) try std.testing.expect(owner.shard.oms.recovery_only and owner.shard.economic_fault_count != 0);
        const recovered = try allocator.create(demo.Owner);
        defer allocator.destroy(recovered);
        try demo.Owner.recoverInto(recovered, memory.interface(), undefined, stream);
        try std.testing.expectEqualSlices(u8, &owner.shard.canonicalStateDigest(), &recovered.shard.canonicalStateDigest());
        const snapshot = try allocator.alloc(u8, durable.max_snapshot_bytes);
        defer allocator.free(snapshot);
        const restored = try allocator.create(trading.TradingShard);
        defer allocator.destroy(restored);
        _ = try trading.TradingShard.restoreSnapshotInto(restored, try owner.committedSnapshot(snapshot));
        try std.testing.expectEqualSlices(u8, &owner.shard.canonicalStateDigest(), &restored.canonicalStateDigest());
        try std.testing.expectEqual(@as(u64, 0), transport.calls);
    }
}

//! Stable, Venue-neutral values that cross the Adapter seams.
//!
//! These values deliberately contain no transport object, Venue field name, or
//! mutable TradingShard state. Venue implementations translate into this
//! module; TradingShard adoption is an incremental, provisional-schema change.

const std = @import("std");

pub const schema_version: u16 = 13;

pub const VenueIdentity = u64;
pub const Product = enum(u8) { spot, isolated_linear_usdt };
pub const AssetIdentity = u64;
pub const ExchangeAccountIdentity = u128;
pub const InstrumentIdentity = u128;
pub const OrderIdentity = u128;
pub const ClientOrderId = OpaqueRef(64);
pub const VenueOrderRef = VenueScopedRef(64);
pub const VenueTradeRef = VenueScopedRef(64);
pub const AdapterSessionIdentity = u128;
pub const BootstrapSnapshotIdentity = u128;
pub const StreamIdentity = u128;
pub const StreamSequence = u64;
pub const VenueSourceStreamIdentity = u128;
pub const VenueSourceSequence = u64;
pub const SourceFactIdentity = u128;

pub const EventIdentity = struct {
    stream: StreamIdentity,
    sequence: StreamSequence,
};

pub fn OpaqueRef(comptime capacity: usize) type {
    return struct {
        bytes: [capacity]u8 = @splat(0),
        len: std.math.IntFittingRange(0, capacity) = 0,

        pub fn init(value: []const u8) !@This() {
            if (value.len == 0 or value.len > capacity) return error.InvalidOpaqueRef;
            var result: @This() = .{ .len = @intCast(value.len) };
            @memcpy(result.bytes[0..value.len], value);
            return result;
        }

        pub fn slice(self: *const @This()) []const u8 {
            return self.bytes[0..self.len];
        }
    };
}

pub fn VenueScopedRef(comptime capacity: usize) type {
    return struct {
        venue: VenueIdentity,
        value: OpaqueRef(capacity),

        pub fn init(venue: VenueIdentity, value: []const u8) !@This() {
            return .{ .venue = venue, .value = try OpaqueRef(capacity).init(value) };
        }
    };
}

pub const Decimal = struct {
    coefficient: i128,
    scale: u8,

    pub const max_text_bytes = 1024;
    pub const max_scale = 38;

    pub fn faultReason(err: anyerror) ?EconomicFaultReason {
        return switch (err) {
            error.UnknownAssetDefinition, error.UnsupportedAsset => .unknown_asset,
            error.MissingAsset, error.MissingFeeAsset, error.MissingRebateAsset => .missing_asset,
            error.NativeAssetCapacityExceeded, error.LedgerCapacityExceeded, error.EconomicFactCapacityExceeded, error.AssetRegistryFull => .capacity_exhausted,
            error.AssetDefinitionInactive => .invalid_economic_fact,
            error.AssetAmountOutOfRange => .overflow,
            error.InvalidDecimal => .malformed_amount,
            error.InexactDecimal => .inexact_amount,
            error.DecimalOverflow, error.DecimalTextTooLong, error.DecimalScaleOutOfRange, error.DecimalRescaleOutOfRange, error.DecimalScalingOverflow => .overflow,
            else => null,
        };
    }

    /// Parses ordinary Venue decimal text without float conversion or rounding.
    pub fn parse(text: []const u8) !Decimal {
        if (text.len == 0) return error.InvalidDecimal;
        if (text.len > max_text_bytes) return error.DecimalTextTooLong;
        var cursor: usize = 0;
        var negative = false;
        if (text[cursor] == '-' or text[cursor] == '+') {
            negative = text[cursor] == '-';
            cursor += 1;
            if (cursor == text.len) return error.InvalidDecimal;
        }

        const start = cursor;
        var dot: ?usize = null;
        var digit_count: usize = 0;
        while (cursor < text.len) : (cursor += 1) {
            const byte = text[cursor];
            if (byte == '.') {
                if (dot != null) return error.InvalidDecimal;
                dot = cursor;
                continue;
            }
            if (byte < '0' or byte > '9') return error.InvalidDecimal;
            digit_count += 1;
        }
        if (digit_count == 0) return error.InvalidDecimal;
        var end = text.len;
        const scale: usize = if (dot) |point| blk: {
            while (end > point + 1 and text[end - 1] == '0') end -= 1;
            break :blk end - point - 1;
        } else 0;
        if (scale > max_scale) return error.DecimalScaleOutOfRange;
        var coefficient: i128 = 0;
        for (text[start..end]) |byte| {
            if (byte == '.') continue;
            coefficient = std.math.mul(i128, coefficient, 10) catch return error.DecimalOverflow;
            coefficient = if (negative)
                std.math.sub(i128, coefficient, byte - '0') catch return error.DecimalOverflow
            else
                std.math.add(i128, coefficient, byte - '0') catch return error.DecimalOverflow;
        }
        return .{ .coefficient = coefficient, .scale = if (coefficient == 0) 0 else @intCast(scale) };
    }

    /// Converts only exactly representable decimals to active-rule atomic units.
    pub fn exactAtoms(self: Decimal, atomic_scale: u8) !i128 {
        if (self.scale > max_scale) return error.DecimalScaleOutOfRange;
        if (atomic_scale > max_scale) return error.DecimalRescaleOutOfRange;
        if (self.scale == atomic_scale) return self.coefficient;
        if (self.scale < atomic_scale) {
            const multiplier = try pow10(atomic_scale - self.scale);
            return std.math.mul(i128, self.coefficient, multiplier) catch error.DecimalScalingOverflow;
        }
        const divisor = try pow10(self.scale - atomic_scale);
        if (@rem(self.coefficient, divisor) != 0) return error.InexactDecimal;
        return @divTrunc(self.coefficient, divisor);
    }
};

fn pow10(exponent: u8) !i128 {
    var result: i128 = 1;
    var index: u8 = 0;
    while (index < exponent) : (index += 1)
        result = std.math.mul(i128, result, 10) catch return error.DecimalOverflow;
    return result;
}

/// Owner-published unit and bounded arithmetic scope; fixture evidence never qualifies production.
pub const max_asset_code_bindings = 4;
pub const max_asset_definitions = 128;
pub const max_instrument_definitions = 125;
pub const AssetCodeBinding = struct {
    venue: VenueIdentity = 0,
    code: [16]u8 = @splat(0),
    code_len: u8 = 0,

    pub fn init(venue: VenueIdentity, code: []const u8) !AssetCodeBinding {
        if (venue == 0 or code.len == 0 or code.len > 16) return error.InvalidAssetCode;
        var result: AssetCodeBinding = .{ .venue = venue, .code_len = @intCast(code.len) };
        for (code) |byte| if (!std.ascii.isAlphanumeric(byte) and byte != '-' and byte != '_') return error.InvalidAssetCode;
        @memcpy(result.code[0..code.len], code);
        return result;
    }
    pub fn slice(self: *const AssetCodeBinding) []const u8 {
        return self.code[0..self.code_len];
    }
};
pub const AssetDefinition = struct {
    asset: AssetIdentity,
    atomic_scale: u8,
    version: u64,
    source_identity: u128,
    source_digest: [32]u8,
    source_kind: enum(u8) { test_fixture, venue_economic_fields },
    max_single_atoms: i128,
    max_balance_atoms: i128,
    max_cumulative_atoms: i128,
    max_quantity_lots: i64,
    max_price_ticks: i64,
    max_rescale_power: u8,
    max_postings: u16,
    code_binding_count: u8 = 0,
    code_bindings: [max_asset_code_bindings]AssetCodeBinding = @splat(.{}),
};

pub const AssetAmount = struct {
    asset: AssetIdentity,
    atoms: i128,

    pub fn fromDecimal(asset: AssetIdentity, value: Decimal, atomic_scale: u8) !AssetAmount {
        return .{ .asset = asset, .atoms = try value.exactAtoms(atomic_scale) };
    }
};
pub const InstrumentPrice = struct {
    instrument: InstrumentIdentity,
    rules_version: u64,
    ticks: i128,

    pub fn fromDecimal(instrument: InstrumentIdentity, rules_version: u64, value: Decimal, tick_scale: u8, tick_atoms: i128) !InstrumentPrice {
        const atoms = try value.exactAtoms(tick_scale);
        if (tick_atoms <= 0 or @rem(atoms, tick_atoms) != 0) return error.InexactInstrumentPrice;
        return .{ .instrument = instrument, .rules_version = rules_version, .ticks = @divTrunc(atoms, tick_atoms) };
    }
};
pub const InstrumentQuantity = struct {
    instrument: InstrumentIdentity,
    rules_version: u64,
    lots: i128,

    pub fn fromDecimal(instrument: InstrumentIdentity, rules_version: u64, value: Decimal, lot_scale: u8, lot_atoms: i128) !InstrumentQuantity {
        const atoms = try value.exactAtoms(lot_scale);
        if (lot_atoms <= 0 or @rem(atoms, lot_atoms) != 0) return error.InexactInstrumentQuantity;
        return .{ .instrument = instrument, .rules_version = rules_version, .lots = @divTrunc(atoms, lot_atoms) };
    }
};

pub const RawEvidenceRef = struct {
    stream: VenueSourceStreamIdentity,
    sequence: VenueSourceSequence,
    digest: [32]u8,
};

pub const Times = struct {
    source_utc_ns: ?u64 = null,
    receive_utc_ns: ?u64 = null,
    monotonic_ns: ?u64 = null,
    audit_utc_ns: ?u64 = null,
};

pub const CanonicalEventScope = enum(u8) { venue, account, instrument, asset };

pub const EventEnvelope = struct {
    event_type: u32,
    schema_version: u16,
    identity: EventIdentity,
    source_fact_identity: SourceFactIdentity,
    scope: CanonicalEventScope,
    venue: VenueIdentity,
    exchange_account: ?ExchangeAccountIdentity = null,
    instrument: ?InstrumentIdentity = null,
    asset: ?AssetIdentity = null,
    source_stream: VenueSourceStreamIdentity,
    source_sequence: VenueSourceSequence,
    source_previous_sequence: ?VenueSourceSequence = null,
    source_cross_sequence: ?VenueSourceSequence = null,
    adapter_session: ?AdapterSessionIdentity = null,
    bootstrap_snapshot: ?BootstrapSnapshotIdentity = null,
    times: Times,
    raw_evidence: RawEvidenceRef,
};

pub const CanonicalRejectReason = enum(u8) {
    capability_unsupported,
    unsupported_instrument,
    unsupported_value,
    stale_version,
    deadline_expired,
    adapter_backpressure,
    venue_unavailable,
    other_venue_reject,
};

pub const DispatchState = enum(u8) { not_sent, submitted, unknown };
pub const OrderOperation = enum(u8) { place, amend, cancel };
pub const OrderSide = enum(u8) { buy, sell };
pub const OrderType = enum(u8) { market, limit, post_only, fok, ioc };
pub const LiquidityRole = enum(u8) { maker, taker };
pub const ExecutionReportStatus = enum(u8) { accepted, partially_filled, filled, canceled, rejected, amended };

pub const OrderCommand = struct {
    identity: OrderIdentity,
    exchange_account: ExchangeAccountIdentity,
    instrument: InstrumentIdentity,
    client_order_id: ClientOrderId,
    capability_version: u64,
    rules_version: u64,
    config_version: u64,
    adapter_session: AdapterSessionIdentity,
    dispatch_deadline_monotonic_ns: u64,
    operation: OrderOperation = .place,
    side: OrderSide = .buy,
    revision: u32 = 1,
    order_type: OrderType = .limit,
    time_in_force: TimeInForce = .good_til_canceled,
    portfolio_reduce_only: bool = false,
    venue_reduce_only: bool = false,
    venue_order: ?VenueOrderRef = null,
    quantity: ?InstrumentQuantity = null,
    limit_price: ?InstrumentPrice = null,
    market_protection_price: ?InstrumentPrice = null,
    fee_asset: ?AssetIdentity = null,
    fee_atoms: i128 = 0,
    rebate_asset: ?AssetIdentity = null,
    rebate_atoms: i128 = 0,
    realized_pnl_asset: ?AssetIdentity = null,
    realized_pnl_atoms: i128 = 0,
    liquidity: LiquidityRole = .taker,
};

pub const max_order_commands_per_batch = 4;
pub const OrderCommandBatch = struct {
    commands: [max_order_commands_per_batch]OrderCommand = undefined,
    len: u8 = 0,

    pub fn append(self: *OrderCommandBatch, command: OrderCommand) !void {
        if (batchCapacityReached(self.len, max_order_commands_per_batch)) return error.OrderBatchFull;
        self.commands[self.len] = command;
        self.len += 1;
    }

    pub fn slice(self: *const OrderCommandBatch) []const OrderCommand {
        return self.commands[0..self.len];
    }
};

pub const OrderReconciliationRequest = struct {
    identity: u128,
    exchange_account: ExchangeAccountIdentity,
    order: OrderIdentity,
    venue_order: ?VenueOrderRef = null,
};

pub const AccountReconciliationRequest = struct {
    identity: u128,
    exchange_account: ExchangeAccountIdentity,
    expected_session: AdapterSessionIdentity,
    economic_boundary_utc_ns: ?u64 = null,
    economic_through_utc_ns: ?u64 = null,
};

pub const AdapterRequest = union(enum) {
    order_command: OrderCommand,
    order_batch: OrderCommandBatch,
    order_reconciliation: OrderReconciliationRequest,
    account_reconciliation: AccountReconciliationRequest,
};

pub const OrderDispatchResult = struct {
    command: OrderIdentity,
    state: DispatchState,
    reason: ?CanonicalRejectReason = null,
};
pub const InstrumentDefinitionObserved = struct { instrument: InstrumentIdentity, rules_version: u64 };
pub const L2BookSnapshot = struct {
    instrument: InstrumentIdentity,
    sequence: VenueSourceSequence,
    complete: bool = true,
    best_bid: InstrumentPrice,
    best_ask: InstrumentPrice,
    best_bid_quantity: ?InstrumentQuantity = null,
    best_ask_quantity: ?InstrumentQuantity = null,
    next_ask: ?InstrumentPrice = null,
    next_ask_quantity: ?InstrumentQuantity = null,
};
pub const L2BookDelta = struct {
    instrument: InstrumentIdentity,
    previous_sequence: VenueSourceSequence,
    sequence: VenueSourceSequence,
    best_bid: InstrumentPrice,
    best_ask: InstrumentPrice,
    best_bid_quantity: ?InstrumentQuantity = null,
    best_ask_quantity: ?InstrumentQuantity = null,
    next_ask: ?InstrumentPrice = null,
    next_ask_quantity: ?InstrumentQuantity = null,
};
pub const ReferencePriceKind = enum(u8) { mark, index };
pub const ReferencePrice = struct { instrument: InstrumentIdentity, kind: ReferencePriceKind, price: InstrumentPrice };
pub const FundingRatePublished = struct { instrument: InstrumentIdentity, rate_ppm: i64, funding_time_utc_ns: u64 };
pub const MarketDataHealth = enum(u8) { awaiting_snapshot, healthy, gap };
pub const MarketDataHealthChanged = struct { instrument: InstrumentIdentity, health: MarketDataHealth };

pub const PositionSide = enum(u8) { net, long, short };
pub const AccountBalance = struct {
    asset: AssetIdentity,
    total: AssetAmount,
    available: AssetAmount,
    held: AssetAmount,
    liability: ?AssetAmount = null,
    cash_balance: ?AssetAmount = null,
    isolated_liability: ?AssetAmount = null,
    cross_liability: ?AssetAmount = null,
};
pub const AccountPosition = struct {
    instrument: InstrumentIdentity,
    side: PositionSide,
    quantity: InstrumentQuantity,
    average_price: ?InstrumentPrice = null,
    mark_price: ?InstrumentPrice = null,
    liquidation_price: ?InstrumentPrice = null,
    margin: ?AssetAmount = null,
    leverage: ?Decimal = null,
    unrealized_pnl: ?AssetAmount = null,
};
/// USD valuations retain source decimals; they are never native cash.
pub const AccountMarginUsdValuation = struct {
    total_equity: ?Decimal = null,
    adjusted_equity: ?Decimal = null,
    initial_margin: ?Decimal = null,
    maintenance_margin: ?Decimal = null,
    isolated_equity: ?Decimal = null,
};
pub const AccountMargin = struct {
    instrument: ?InstrumentIdentity = null,
    amount: ?AssetAmount = null,
    adjusted_equity: ?AssetAmount = null,
    initial_margin: ?AssetAmount = null,
    maintenance_margin: ?AssetAmount = null,
    isolated_equity: ?AssetAmount = null,
    margin_ratio: ?Decimal = null,
    usd_valuation: ?AccountMarginUsdValuation = null,
};
pub const max_account_facts = 8;
pub const AccountSnapshotScope = struct { balances_complete: bool, positions_complete: bool, margins_complete: bool };

pub const AccountBootstrapSnapshot = struct {
    identity: BootstrapSnapshotIdentity,
    exchange_account: ExchangeAccountIdentity,
    scope: AccountSnapshotScope,
    source_stream: VenueSourceStreamIdentity,
    source_sequence: VenueSourceSequence,
    balances: [max_account_facts]AccountBalance = undefined,
    balance_count: u8,
    positions: [max_account_facts]AccountPosition = undefined,
    position_count: u8,
    margins: [max_account_facts]AccountMargin = undefined,
    margin_count: u8,
};

pub const AccountObserved = union(enum) {
    balance: struct { asset: AssetIdentity, value: AccountBalance, removed: bool = false },
    position: struct { instrument: InstrumentIdentity, side: PositionSide, value: AccountPosition, removed: bool = false },
    margin: struct { instrument: ?InstrumentIdentity = null, value: AccountMargin, removed: bool = false },
};

pub const AccountObservation = struct {
    identity: SourceFactIdentity,
    exchange_account: ExchangeAccountIdentity,
    bootstrap: BootstrapSnapshotIdentity,
    source_stream: VenueSourceStreamIdentity,
    source_sequence: VenueSourceSequence,
    value: AccountObserved,
};

pub const ReconciliationStatus = enum(u8) { found_live, found_terminal, confirmed_absent, unresolved };
pub const OrderQueryScope = struct {
    exchange_account: ExchangeAccountIdentity,
    instrument: InstrumentIdentity,
    order: OrderIdentity,
    revision: u32,
    from_utc_ns: u64,
    through_utc_ns: u64,
};
pub const AbsenceCoverage = struct {
    prior_session: AdapterSessionIdentity,
    prior_session_inactive: bool,
    visibility_deadline_utc_ns: u64,
    order_history_complete: bool,
    terminal_history_complete: bool,
    fills_complete: bool,
    economics_complete: bool,
};
pub const TerminalArchiveCoverage = struct {
    visibility_deadline_utc_ns: u64,
    order_history_complete: bool,
    terminal_history_complete: bool,
    fills_complete: bool,
    economics_complete: bool,
};
pub const ReconciliationEvidence = struct {
    scope: OrderQueryScope,
    observed_at_utc_ns: u64,
    source: RawEvidenceRef,
    absence: ?AbsenceCoverage = null,
    terminal_archive: ?TerminalArchiveCoverage = null,
};
pub const ReconciliationResult = struct {
    identity: u128,
    complete: bool,
    status: ReconciliationStatus = .unresolved,
    order: OrderIdentity = 0,
    revision: u32 = 0,
    cumulative_quantity: ?InstrumentQuantity = null,
    remaining_quantity: ?InstrumentQuantity = null,
    terminal_status: ?ExecutionReportStatus = null,
    rules_version: u64 = 0,
    evidence: ?ReconciliationEvidence = null,
    account_economics: ?AccountEconomicEvidence = null,
};

/// Native cash snapshots plus scoped bill and canonical fact references prove
/// an economic interval. Receipt/Adapter sequences do not certify economics.
pub const AccountEconomicEvidence = struct {
    exchange_account: ExchangeAccountIdentity,
    scope: enum(u8) { spot_and_isolated_linear_usdt },
    from_utc_ns: u64,
    through_utc_ns: u64,
    source: RawEvidenceRef,
    balances: [max_account_facts]AssetAmount = @splat(.{ .asset = 0, .atoms = 0 }),
    asset_versions: [max_account_facts]u64 = @splat(0),
    balance_count: u8 = 0,
    covered_economic_fact_count: u16 = 0,
    before_source: ?RawEvidenceRef = null,
    before_balances: [max_account_facts]AssetAmount = @splat(.{ .asset = 0, .atoms = 0 }),
    before_balance_count: u8 = 0,
    query_sources: [4]RawEvidenceRef = @splat(.{ .stream = 0, .sequence = 0, .digest = @splat(0) }),
    query_count: u8 = 0,
    bills_complete: bool = false,
    bill_chain_digest: [32]u8 = @splat(0),
    facts: [16]EconomicFactRef = @splat(.{ .identity = 0, .kind = .funding, .digest = @splat(0), .fee_confirmed = false }),
};
pub const EconomicFactRef = struct { identity: u64, kind: enum(u8) { fill, funding, forced }, digest: [32]u8, fee_confirmed: bool };

pub const ExecutionReport = struct {
    identity: SourceFactIdentity,
    order: OrderIdentity,
    client_order_id: ClientOrderId,
    venue_order: ?VenueOrderRef = null,
    instrument: InstrumentIdentity,
    exchange_account: ExchangeAccountIdentity,
    revision: u32,
    side: OrderSide = .buy,
    order_type: ?OrderType = null,
    time_in_force: ?TimeInForce = null,
    venue_reduce_only: ?bool = null,
    position_mode_net: ?bool = null,
    margin_mode_isolated: ?bool = null,
    leverage: ?Decimal = null,
    status: ExecutionReportStatus,
    reject_reason: ?CanonicalRejectReason = null,
    portfolio_reduce_only: ?bool = null,
    position_side: ?PositionSide = null,
    original_quantity: ?InstrumentQuantity = null,
    cumulative_quantity: InstrumentQuantity,
    remaining_quantity: InstrumentQuantity,
    limit_price: ?InstrumentPrice = null,
    average_fill_price: ?InstrumentPrice = null,
    venue_create_time_utc_ns: ?u64 = null,
    venue_update_time_utc_ns: ?u64 = null,
};

pub const Fill = struct {
    identity: SourceFactIdentity,
    order: OrderIdentity,
    client_order_id: ClientOrderId,
    venue_order: VenueOrderRef,
    venue_trade: VenueTradeRef,
    instrument: InstrumentIdentity,
    exchange_account: ExchangeAccountIdentity,
    side: OrderSide,
    quantity: InstrumentQuantity,
    price: InstrumentPrice,
    fee: ?AssetAmount = null,
    rebate: ?AssetAmount = null,
    realized_pnl: ?AssetAmount = null,
    liquidity: LiquidityRole,
    venue_fill_time_utc_ns: ?u64 = null,
};

pub const VenueAccountConfigurationSnapshot = struct {
    identity: SourceFactIdentity,
    exchange_account: ExchangeAccountIdentity,
    value: union(enum) {
        account: struct {
            position_mode_net: bool,
            contract_isolated_autonomy: bool,
            auto_loan: bool,
            spot_borrow_enabled: bool,
            can_read: bool,
            can_trade: bool,
            can_withdraw: bool,
        },
        isolated_leverage: struct {
            instrument: InstrumentIdentity,
            position_mode_net: bool,
            margin_mode_isolated: bool,
            leverage: Decimal,
        },
    },
};

pub const EconomicFaultReason = enum(u8) { missing_amount, missing_asset, unknown_asset, malformed_amount, inexact_amount, overflow, invalid_economic_fact, decoder_rejected, persistence_failure, capacity_exhausted };
pub const EconomicFault = struct { reason: EconomicFaultReason };
pub const FundingSettlement = struct {
    identity: SourceFactIdentity,
    exchange_account: ExchangeAccountIdentity,
    instrument: InstrumentIdentity,
    rules_version: u64,
    venue_bill_id: u64,
    amount: AssetAmount,
    settlement_time_utc_ns: u64,
};

pub const Payload = union(enum) {
    economic_fault: EconomicFault,
    order_dispatch_result: OrderDispatchResult,
    execution_report: ExecutionReport,
    fill: Fill,
    reconciliation_started: u128,
    account_reconciliation_started: u128,
    instrument_definition_observed: InstrumentDefinitionObserved,
    l2_book_snapshot: L2BookSnapshot,
    l2_book_delta: L2BookDelta,
    reference_price: ReferencePrice,
    funding_rate_published: FundingRatePublished,
    market_data_health_changed: MarketDataHealthChanged,
    account_bootstrap_snapshot: AccountBootstrapSnapshot,
    account_observed: AccountObservation,
    venue_account_configuration_snapshot: VenueAccountConfigurationSnapshot,
    order_reconciliation_result: ReconciliationResult,
    account_reconciliation_result: ReconciliationResult,
    funding_settlement: FundingSettlement,
};

pub const EventType = enum(u32) {
    economic_fault = 22,
    funding_settlement = 23,
    order_dispatch_result = 1,
    execution_report = 3,
    fill = 4,
    reconciliation_started = 5,
    account_reconciliation_started = 6,
    account_bootstrap_snapshot = 11,
    account_observed = 12,
    venue_account_configuration_snapshot = 13,
    order_reconciliation_result = 14,
    account_reconciliation_result = 15,
    instrument_definition_observed = 16,
    l2_book_snapshot = 17,
    l2_book_delta = 18,
    reference_price = 19,
    funding_rate_published = 20,
    market_data_health_changed = 21,
};

pub const TimeInForce = enum(u8) { good_til_canceled, immediate_or_cancel, fill_or_kill, post_only };

pub fn eventType(event: Payload) EventType {
    return switch (event) {
        .economic_fault => .economic_fault,
        .funding_settlement => .funding_settlement,
        .order_dispatch_result => .order_dispatch_result,
        .execution_report => .execution_report,
        .fill => .fill,
        .reconciliation_started => .reconciliation_started,
        .account_reconciliation_started => .account_reconciliation_started,
        .account_bootstrap_snapshot => .account_bootstrap_snapshot,
        .account_observed => .account_observed,
        .venue_account_configuration_snapshot => .venue_account_configuration_snapshot,
        .order_reconciliation_result => .order_reconciliation_result,
        .account_reconciliation_result => .account_reconciliation_result,
        .instrument_definition_observed => .instrument_definition_observed,
        .l2_book_snapshot => .l2_book_snapshot,
        .l2_book_delta => .l2_book_delta,
        .reference_price => .reference_price,
        .funding_rate_published => .funding_rate_published,
        .market_data_health_changed => .market_data_health_changed,
    };
}

pub const EventRecord = struct { envelope: EventEnvelope, event: Payload };

/// Validates bounded counts and removes undefined fixed-array tails before an
/// event participates in hashing or durable encoding.
pub fn normalizedForStorage(record: EventRecord) !EventRecord {
    var normalized = record;
    switch (normalized.event) {
        .account_bootstrap_snapshot => |*snapshot| {
            if (snapshot.balance_count > snapshot.balances.len or
                snapshot.position_count > snapshot.positions.len or
                snapshot.margin_count > snapshot.margins.len)
                return error.InvalidAccountFactCount;
            for (snapshot.balances[snapshot.balance_count..]) |*value| value.* = std.mem.zeroes(AccountBalance);
            for (snapshot.positions[snapshot.position_count..]) |*value| value.* = std.mem.zeroes(AccountPosition);
            for (snapshot.margins[snapshot.margin_count..]) |*value| value.* = std.mem.zeroes(AccountMargin);
        },
        else => {},
    }
    return normalized;
}

pub const max_events_per_adapter_batch = 32;
pub const AdapterOutputBatch = struct {
    events: [max_events_per_adapter_batch]EventRecord = undefined,
    len: u8 = 0,

    pub fn append(self: *AdapterOutputBatch, event: EventRecord) !void {
        if (batchCapacityReached(self.len, max_events_per_adapter_batch)) return error.AdapterOutputFull;
        self.events[self.len] = event;
        self.len += 1;
    }

    pub fn slice(self: *const AdapterOutputBatch) []const EventRecord {
        return self.events[0..self.len];
    }
};

fn batchCapacityReached(count: usize, capacity: usize) bool {
    return count >= capacity;
}

test "09 boundary Adapter batches reject full and excess counts without populating output" {
    for ([_]usize{ max_order_commands_per_batch, max_events_per_adapter_batch }) |capacity| {
        try std.testing.expect(!batchCapacityReached(capacity - 1, capacity));
        try std.testing.expect(batchCapacityReached(capacity, capacity));
        try std.testing.expect(batchCapacityReached(capacity + 1, capacity));
        try std.testing.expect(batchCapacityReached(std.math.maxInt(usize), capacity));
    }
}

test "decimal conversion is lossless and exact" {
    const value = try Decimal.parse("-12.3400");
    try std.testing.expectEqual(@as(i128, -1234), value.coefficient);
    try std.testing.expectEqual(@as(u8, 2), value.scale);
    try std.testing.expectEqual(@as(i128, -1234), try value.exactAtoms(2));
    try std.testing.expectEqual(@as(i128, -1234), (try AssetAmount.fromDecimal(3, value, 2)).atoms);
    try std.testing.expectEqual(@as(i128, -24680), (try InstrumentPrice.fromDecimal(4, 5, value, 4, 5)).ticks);
    try std.testing.expectEqual(@as(i128, -617), (try InstrumentQuantity.fromDecimal(4, 5, value, 2, 2)).lots);
    try std.testing.expectError(error.InexactDecimal, (try Decimal.parse("1.001")).exactAtoms(2));
    try std.testing.expectError(error.InexactInstrumentPrice, InstrumentPrice.fromDecimal(4, 5, try Decimal.parse("0.01"), 2, 5));
}

test "opaque venue references are bounded" {
    const order = try VenueOrderRef.init(3, "venue-order-1");
    try std.testing.expectEqual(@as(VenueIdentity, 3), order.venue);
    try std.testing.expectEqualStrings("venue-order-1", order.value.slice());
    try std.testing.expectError(error.InvalidOpaqueRef, VenueTradeRef.init(3, ""));
}

test "bounded decimal text normalizes before accumulation and preserves signed limits" {
    for ([_][]const u8{ "1", "+0001.0000000000000000000000000000000000000000000000000000000000000000" }) |text| {
        const value = try Decimal.parse(text);
        try std.testing.expectEqual(@as(i128, 1), value.coefficient);
        try std.testing.expectEqual(@as(u8, 0), value.scale);
    }
    for ([_][]const u8{ "0", "-000.000", "+.0000000000000000000000000000000000000000" }) |text| {
        const value = try Decimal.parse(text);
        try std.testing.expectEqual(@as(i128, 0), value.coefficient);
        try std.testing.expectEqual(@as(u8, 0), value.scale);
    }
    try std.testing.expectEqual(std.math.maxInt(i128), (try Decimal.parse("170141183460469231731687303715884105727")).coefficient);
    try std.testing.expectEqual(std.math.minInt(i128), (try Decimal.parse("-170141183460469231731687303715884105728")).coefficient);
    try std.testing.expectError(error.DecimalOverflow, Decimal.parse("170141183460469231731687303715884105728"));
    try std.testing.expectError(error.DecimalOverflow, Decimal.parse("-170141183460469231731687303715884105729"));
    for ([_][]const u8{ "", "+", "-", ".", "0.0.0", "1e2", " 0", "0x" }) |text|
        try std.testing.expectError(error.InvalidDecimal, Decimal.parse(text));
    var long_text: [1025]u8 = @splat('0');
    long_text[1023] = '1';
    try std.testing.expectEqual(@as(i128, 1), (try Decimal.parse(long_text[0..1024])).coefficient);
    try std.testing.expectError(error.DecimalTextTooLong, Decimal.parse(&long_text));
    var fractional: [41]u8 = @splat('0');
    fractional[1] = '.';
    fractional[39] = '1';
    try std.testing.expectEqual(@as(i128, 1), try (try Decimal.parse(fractional[0..40])).exactAtoms(38));
    fractional[40] = '1';
    try std.testing.expectError(error.DecimalScaleOutOfRange, Decimal.parse(&fractional));
    try std.testing.expectError(error.DecimalRescaleOutOfRange, (try Decimal.parse("1")).exactAtoms(39));
    try std.testing.expectError(error.DecimalScaleOutOfRange, (Decimal{ .coefficient = 1, .scale = 39 }).exactAtoms(38));
    try std.testing.expectError(error.DecimalScalingOverflow, (try Decimal.parse("170141183460469231731687303715884105727")).exactAtoms(1));
}
